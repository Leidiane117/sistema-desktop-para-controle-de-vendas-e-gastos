﻿namespace SeitonSystem.src.view
{
    partial class MensagensView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_voltar = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.lbl_msg = new System.Windows.Forms.Label();
            this.p_um = new System.Windows.Forms.Panel();
            this.p_dois = new System.Windows.Forms.Panel();
            this.p_tres = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pic_info = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pic_info)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_voltar
            // 
            this.btn_voltar.BackColor = System.Drawing.Color.Transparent;
            this.btn_voltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_voltar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.btn_voltar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_voltar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(156)))), ((int)(((byte)(154)))));
            this.btn_voltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_voltar.Location = new System.Drawing.Point(206, 105);
            this.btn_voltar.Name = "btn_voltar";
            this.btn_voltar.Size = new System.Drawing.Size(106, 35);
            this.btn_voltar.TabIndex = 14;
            this.btn_voltar.Text = "Voltar";
            this.btn_voltar.UseVisualStyleBackColor = false;
            this.btn_voltar.Click += new System.EventHandler(this.btn_voltar_Click);
            // 
            // btn_ok
            // 
            this.btn_ok.BackColor = System.Drawing.Color.Transparent;
            this.btn_ok.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ok.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.btn_ok.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_ok.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(156)))), ((int)(((byte)(154)))));
            this.btn_ok.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ok.Location = new System.Drawing.Point(12, 105);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(106, 35);
            this.btn_ok.TabIndex = 15;
            this.btn_ok.Text = "Ok";
            this.btn_ok.UseVisualStyleBackColor = false;
            this.btn_ok.Visible = false;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // lbl_msg
            // 
            this.lbl_msg.BackColor = System.Drawing.Color.Transparent;
            this.lbl_msg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_msg.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_msg.ForeColor = System.Drawing.Color.White;
            this.lbl_msg.Location = new System.Drawing.Point(88, 9);
            this.lbl_msg.Name = "lbl_msg";
            this.lbl_msg.Size = new System.Drawing.Size(224, 79);
            this.lbl_msg.TabIndex = 16;
            this.lbl_msg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // p_um
            // 
            this.p_um.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.p_um.Location = new System.Drawing.Point(321, 0);
            this.p_um.Name = "p_um";
            this.p_um.Size = new System.Drawing.Size(3, 153);
            this.p_um.TabIndex = 18;
            // 
            // p_dois
            // 
            this.p_dois.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.p_dois.Location = new System.Drawing.Point(0, 0);
            this.p_dois.Name = "p_dois";
            this.p_dois.Size = new System.Drawing.Size(3, 153);
            this.p_dois.TabIndex = 19;
            // 
            // p_tres
            // 
            this.p_tres.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.p_tres.Location = new System.Drawing.Point(0, 0);
            this.p_tres.Name = "p_tres";
            this.p_tres.Size = new System.Drawing.Size(324, 3);
            this.p_tres.TabIndex = 20;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.panel1.Location = new System.Drawing.Point(3, 150);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(326, 3);
            this.panel1.TabIndex = 21;
            // 
            // pic_info
            // 
            this.pic_info.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_info.Location = new System.Drawing.Point(12, 26);
            this.pic_info.Name = "pic_info";
            this.pic_info.Size = new System.Drawing.Size(70, 47);
            this.pic_info.TabIndex = 17;
            this.pic_info.TabStop = false;
            // 
            // Messagens
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(156)))), ((int)(((byte)(154)))));
            this.ClientSize = new System.Drawing.Size(324, 154);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.p_tres);
            this.Controls.Add(this.p_dois);
            this.Controls.Add(this.p_um);
            this.Controls.Add(this.pic_info);
            this.Controls.Add(this.lbl_msg);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.btn_voltar);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Messagens";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Message ";
            ((System.ComponentModel.ISupportInitialize)(this.pic_info)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_voltar;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Label lbl_msg;
        private System.Windows.Forms.PictureBox pic_info;
        private System.Windows.Forms.Panel p_um;
        private System.Windows.Forms.Panel p_dois;
        private System.Windows.Forms.Panel p_tres;
        private System.Windows.Forms.Panel panel1;
    }
}