﻿namespace SeitonSystem.src.view.Inicial
{
    partial class InicialView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InicialView));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btn_tbPedidos = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btn_Add_Produto = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btn_add_cliente = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_abrir_manual = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btn_ajuda = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txt_lucro = new System.Windows.Forms.TextBox();
            this.btn_financasCadastrar = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.linha = new System.Windows.Forms.Panel();
            this.btn_finançasView = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label_percent = new System.Windows.Forms.Label();
            this.btn_bakup = new System.Windows.Forms.Button();
            this.btn_financas = new System.Windows.Forms.Button();
            this.btn_pedido = new System.Windows.Forms.Button();
            this.btn_produtos = new System.Windows.Forms.Button();
            this.btn_clientes = new System.Windows.Forms.Button();
            this.dt = new MetroFramework.Controls.MetroGrid();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(115)))), ((int)(((byte)(94)))));
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.btn_tbPedidos);
            this.panel1.Location = new System.Drawing.Point(8, 191);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(325, 170);
            this.panel1.TabIndex = 0;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(24, 44);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(283, 2);
            this.panel8.TabIndex = 18;
            // 
            // btn_tbPedidos
            // 
            this.btn_tbPedidos.BackColor = System.Drawing.Color.Transparent;
            this.btn_tbPedidos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_tbPedidos.FlatAppearance.BorderSize = 0;
            this.btn_tbPedidos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_tbPedidos.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_tbPedidos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_tbPedidos.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tbPedidos.ForeColor = System.Drawing.Color.White;
            this.btn_tbPedidos.Location = new System.Drawing.Point(7, 6);
            this.btn_tbPedidos.Margin = new System.Windows.Forms.Padding(4);
            this.btn_tbPedidos.Name = "btn_tbPedidos";
            this.btn_tbPedidos.Size = new System.Drawing.Size(320, 34);
            this.btn_tbPedidos.TabIndex = 14;
            this.btn_tbPedidos.Text = "Adicionar Novo Pedido";
            this.btn_tbPedidos.UseVisualStyleBackColor = false;
            this.btn_tbPedidos.Click += new System.EventHandler(this.btn_tbPedidos_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(115)))), ((int)(((byte)(94)))));
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.btn_Add_Produto);
            this.panel2.Location = new System.Drawing.Point(652, 191);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(337, 170);
            this.panel2.TabIndex = 1;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.White;
            this.panel10.Controls.Add(this.panel11);
            this.panel10.Location = new System.Drawing.Point(21, 44);
            this.panel10.Margin = new System.Windows.Forms.Padding(4);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(283, 2);
            this.panel10.TabIndex = 20;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Location = new System.Drawing.Point(0, 0);
            this.panel11.Margin = new System.Windows.Forms.Padding(4);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(283, 2);
            this.panel11.TabIndex = 21;
            // 
            // btn_Add_Produto
            // 
            this.btn_Add_Produto.BackColor = System.Drawing.Color.Transparent;
            this.btn_Add_Produto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Add_Produto.FlatAppearance.BorderSize = 0;
            this.btn_Add_Produto.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_Add_Produto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_Add_Produto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Add_Produto.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Add_Produto.ForeColor = System.Drawing.Color.White;
            this.btn_Add_Produto.Location = new System.Drawing.Point(4, 6);
            this.btn_Add_Produto.Margin = new System.Windows.Forms.Padding(4);
            this.btn_Add_Produto.Name = "btn_Add_Produto";
            this.btn_Add_Produto.Size = new System.Drawing.Size(320, 34);
            this.btn_Add_Produto.TabIndex = 15;
            this.btn_Add_Produto.Text = "Adicionar Novo Produto";
            this.btn_Add_Produto.UseVisualStyleBackColor = false;
            this.btn_Add_Produto.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.panel9);
            this.panel3.Controls.Add(this.btn_add_cliente);
            this.panel3.Location = new System.Drawing.Point(333, 191);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(328, 170);
            this.panel3.TabIndex = 2;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.White;
            this.panel9.Location = new System.Drawing.Point(28, 44);
            this.panel9.Margin = new System.Windows.Forms.Padding(4);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(283, 2);
            this.panel9.TabIndex = 19;
            // 
            // btn_add_cliente
            // 
            this.btn_add_cliente.BackColor = System.Drawing.Color.Transparent;
            this.btn_add_cliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_add_cliente.FlatAppearance.BorderSize = 0;
            this.btn_add_cliente.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_add_cliente.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_add_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add_cliente.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add_cliente.ForeColor = System.Drawing.Color.White;
            this.btn_add_cliente.Location = new System.Drawing.Point(7, 6);
            this.btn_add_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.btn_add_cliente.Name = "btn_add_cliente";
            this.btn_add_cliente.Size = new System.Drawing.Size(320, 34);
            this.btn_add_cliente.TabIndex = 15;
            this.btn_add_cliente.Text = "Adicionar Novo Cliente";
            this.btn_add_cliente.UseVisualStyleBackColor = false;
            this.btn_add_cliente.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.panel4.Controls.Add(this.btn_abrir_manual);
            this.panel4.Controls.Add(this.panel13);
            this.panel4.Controls.Add(this.btn_ajuda);
            this.panel4.Location = new System.Drawing.Point(671, 567);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(318, 181);
            this.panel4.TabIndex = 3;
            // 
            // btn_abrir_manual
            // 
            this.btn_abrir_manual.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.btn_abrir_manual.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_abrir_manual.FlatAppearance.BorderSize = 0;
            this.btn_abrir_manual.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_abrir_manual.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_abrir_manual.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_abrir_manual.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.btn_abrir_manual.ForeColor = System.Drawing.Color.Black;
            this.btn_abrir_manual.Location = new System.Drawing.Point(32, 104);
            this.btn_abrir_manual.Margin = new System.Windows.Forms.Padding(4);
            this.btn_abrir_manual.Name = "btn_abrir_manual";
            this.btn_abrir_manual.Size = new System.Drawing.Size(270, 36);
            this.btn_abrir_manual.TabIndex = 22;
            this.btn_abrir_manual.Text = "Consultar Manual";
            this.btn_abrir_manual.UseVisualStyleBackColor = false;
            this.btn_abrir_manual.Click += new System.EventHandler(this.btn_abrir_manual_Click);
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.White;
            this.panel13.Location = new System.Drawing.Point(19, 47);
            this.panel13.Margin = new System.Windows.Forms.Padding(4);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(283, 2);
            this.panel13.TabIndex = 21;
            // 
            // btn_ajuda
            // 
            this.btn_ajuda.BackColor = System.Drawing.Color.Transparent;
            this.btn_ajuda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ajuda.FlatAppearance.BorderSize = 0;
            this.btn_ajuda.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_ajuda.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_ajuda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ajuda.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_ajuda.ForeColor = System.Drawing.Color.White;
            this.btn_ajuda.Image = ((System.Drawing.Image)(resources.GetObject("btn_ajuda.Image")));
            this.btn_ajuda.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_ajuda.Location = new System.Drawing.Point(19, 7);
            this.btn_ajuda.Margin = new System.Windows.Forms.Padding(4);
            this.btn_ajuda.Name = "btn_ajuda";
            this.btn_ajuda.Size = new System.Drawing.Size(266, 40);
            this.btn_ajuda.TabIndex = 18;
            this.btn_ajuda.Text = "Ajuda";
            this.btn_ajuda.UseVisualStyleBackColor = false;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(178)))), ((int)(((byte)(192)))));
            this.panel5.Controls.Add(this.pictureBox1);
            this.panel5.Controls.Add(this.txt_lucro);
            this.panel5.Controls.Add(this.btn_financasCadastrar);
            this.panel5.Controls.Add(this.button7);
            this.panel5.Controls.Add(this.linha);
            this.panel5.Controls.Add(this.btn_finançasView);
            this.panel5.Location = new System.Drawing.Point(8, 567);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(335, 181);
            this.panel5.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Location = new System.Drawing.Point(24, 119);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 48;
            this.pictureBox1.TabStop = false;
            // 
            // txt_lucro
            // 
            this.txt_lucro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_lucro.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_lucro.Location = new System.Drawing.Point(106, 77);
            this.txt_lucro.Name = "txt_lucro";
            this.txt_lucro.ReadOnly = true;
            this.txt_lucro.Size = new System.Drawing.Size(126, 23);
            this.txt_lucro.TabIndex = 50;
            this.txt_lucro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_financasCadastrar
            // 
            this.btn_financasCadastrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.btn_financasCadastrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_financasCadastrar.FlatAppearance.BorderSize = 0;
            this.btn_financasCadastrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_financasCadastrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_financasCadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_financasCadastrar.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.btn_financasCadastrar.ForeColor = System.Drawing.Color.Black;
            this.btn_financasCadastrar.Location = new System.Drawing.Point(24, 118);
            this.btn_financasCadastrar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_financasCadastrar.Name = "btn_financasCadastrar";
            this.btn_financasCadastrar.Size = new System.Drawing.Size(281, 34);
            this.btn_financasCadastrar.TabIndex = 17;
            this.btn_financasCadastrar.Text = "Adicionar Atividade";
            this.btn_financasCadastrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_financasCadastrar.UseVisualStyleBackColor = false;
            this.btn_financasCadastrar.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 10.25F, System.Drawing.FontStyle.Bold);
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(24, 73);
            this.button7.Margin = new System.Windows.Forms.Padding(4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(97, 34);
            this.button7.TabIndex = 18;
            this.button7.TabStop = false;
            this.button7.Text = "Saldo:    ";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // linha
            // 
            this.linha.BackColor = System.Drawing.Color.White;
            this.linha.Location = new System.Drawing.Point(25, 47);
            this.linha.Margin = new System.Windows.Forms.Padding(4);
            this.linha.Name = "linha";
            this.linha.Size = new System.Drawing.Size(283, 2);
            this.linha.TabIndex = 17;
            // 
            // btn_finançasView
            // 
            this.btn_finançasView.BackColor = System.Drawing.Color.Transparent;
            this.btn_finançasView.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_finançasView.FlatAppearance.BorderSize = 0;
            this.btn_finançasView.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_finançasView.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_finançasView.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_finançasView.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_finançasView.ForeColor = System.Drawing.Color.White;
            this.btn_finançasView.Image = ((System.Drawing.Image)(resources.GetObject("btn_finançasView.Image")));
            this.btn_finançasView.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_finançasView.Location = new System.Drawing.Point(5, 7);
            this.btn_finançasView.Margin = new System.Windows.Forms.Padding(4);
            this.btn_finançasView.Name = "btn_finançasView";
            this.btn_finançasView.Size = new System.Drawing.Size(320, 34);
            this.btn_finançasView.TabIndex = 16;
            this.btn_finançasView.Text = "Fluxo de Caixa";
            this.btn_finançasView.UseVisualStyleBackColor = false;
            this.btn_finançasView.Click += new System.EventHandler(this.button3_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(115)))), ((int)(((byte)(94)))));
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.panel12);
            this.panel6.Controls.Add(this.label_percent);
            this.panel6.Controls.Add(this.btn_bakup);
            this.panel6.Location = new System.Drawing.Point(340, 567);
            this.panel6.Margin = new System.Windows.Forms.Padding(4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(333, 181);
            this.panel6.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9.25F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(21, 68);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(154, 42);
            this.button1.TabIndex = 22;
            this.button1.Text = "Processando... %";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.White;
            this.panel12.Location = new System.Drawing.Point(33, 47);
            this.panel12.Margin = new System.Windows.Forms.Padding(4);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(283, 2);
            this.panel12.TabIndex = 21;
            // 
            // label_percent
            // 
            this.label_percent.AutoSize = true;
            this.label_percent.Location = new System.Drawing.Point(28, 84);
            this.label_percent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_percent.Name = "label_percent";
            this.label_percent.Size = new System.Drawing.Size(0, 17);
            this.label_percent.TabIndex = 19;
            // 
            // btn_bakup
            // 
            this.btn_bakup.BackColor = System.Drawing.Color.Transparent;
            this.btn_bakup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_bakup.FlatAppearance.BorderSize = 0;
            this.btn_bakup.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_bakup.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_bakup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bakup.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.btn_bakup.ForeColor = System.Drawing.Color.White;
            this.btn_bakup.Image = ((System.Drawing.Image)(resources.GetObject("btn_bakup.Image")));
            this.btn_bakup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_bakup.Location = new System.Drawing.Point(33, 7);
            this.btn_bakup.Margin = new System.Windows.Forms.Padding(4);
            this.btn_bakup.Name = "btn_bakup";
            this.btn_bakup.Size = new System.Drawing.Size(283, 42);
            this.btn_bakup.TabIndex = 17;
            this.btn_bakup.Text = "Fazer Backup";
            this.btn_bakup.UseVisualStyleBackColor = false;
            this.btn_bakup.Click += new System.EventHandler(this.btn_bakup_Click);
            // 
            // btn_financas
            // 
            this.btn_financas.BackColor = System.Drawing.Color.White;
            this.btn_financas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_financas.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_financas.FlatAppearance.BorderSize = 0;
            this.btn_financas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_financas.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_financas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_financas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_financas.Location = new System.Drawing.Point(797, 0);
            this.btn_financas.Margin = new System.Windows.Forms.Padding(4);
            this.btn_financas.Name = "btn_financas";
            this.btn_financas.Size = new System.Drawing.Size(201, 38);
            this.btn_financas.TabIndex = 11;
            this.btn_financas.Text = "Finanças";
            this.btn_financas.UseVisualStyleBackColor = false;
            this.btn_financas.Click += new System.EventHandler(this.btn_financas_Click);
            // 
            // btn_pedido
            // 
            this.btn_pedido.BackColor = System.Drawing.Color.White;
            this.btn_pedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pedido.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_pedido.FlatAppearance.BorderSize = 0;
            this.btn_pedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_pedido.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_pedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pedido.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pedido.Location = new System.Drawing.Point(581, 0);
            this.btn_pedido.Margin = new System.Windows.Forms.Padding(4);
            this.btn_pedido.Name = "btn_pedido";
            this.btn_pedido.Size = new System.Drawing.Size(220, 38);
            this.btn_pedido.TabIndex = 10;
            this.btn_pedido.Text = "Pedidos";
            this.btn_pedido.UseVisualStyleBackColor = false;
            this.btn_pedido.Click += new System.EventHandler(this.btn_pedido_Click);
            // 
            // btn_produtos
            // 
            this.btn_produtos.BackColor = System.Drawing.Color.White;
            this.btn_produtos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_produtos.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_produtos.FlatAppearance.BorderSize = 0;
            this.btn_produtos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_produtos.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_produtos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_produtos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_produtos.Location = new System.Drawing.Point(196, 0);
            this.btn_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.btn_produtos.Name = "btn_produtos";
            this.btn_produtos.Size = new System.Drawing.Size(209, 38);
            this.btn_produtos.TabIndex = 9;
            this.btn_produtos.Text = "Produtos";
            this.btn_produtos.UseVisualStyleBackColor = false;
            this.btn_produtos.Click += new System.EventHandler(this.btn_produtos_Click);
            // 
            // btn_clientes
            // 
            this.btn_clientes.BackColor = System.Drawing.Color.White;
            this.btn_clientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_clientes.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_clientes.FlatAppearance.BorderSize = 0;
            this.btn_clientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_clientes.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_clientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clientes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clientes.Location = new System.Drawing.Point(-4, 0);
            this.btn_clientes.Margin = new System.Windows.Forms.Padding(4);
            this.btn_clientes.Name = "btn_clientes";
            this.btn_clientes.Size = new System.Drawing.Size(201, 38);
            this.btn_clientes.TabIndex = 8;
            this.btn_clientes.Text = "Clientes";
            this.btn_clientes.UseVisualStyleBackColor = false;
            this.btn_clientes.Click += new System.EventHandler(this.btn_clientes_Click);
            // 
            // dt
            // 
            this.dt.AllowUserToAddRows = false;
            this.dt.AllowUserToDeleteRows = false;
            this.dt.AllowUserToResizeColumns = false;
            this.dt.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            this.dt.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dt.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.dt.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.dt.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dt.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.dt.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dt.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dt.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dt.DefaultCellStyle = dataGridViewCellStyle3;
            this.dt.EnableHeadersVisualStyles = false;
            this.dt.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dt.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dt.Location = new System.Drawing.Point(8, 366);
            this.dt.Margin = new System.Windows.Forms.Padding(4);
            this.dt.MultiSelect = false;
            this.dt.Name = "dt";
            this.dt.ReadOnly = true;
            this.dt.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dt.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dt.RowHeadersWidth = 51;
            this.dt.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            this.dt.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dt.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.dt.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dt.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dt.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            this.dt.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dt.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dt.Size = new System.Drawing.Size(981, 193);
            this.dt.TabIndex = 47;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::SeitonSystem.Properties.Resources.logo2;
            this.pictureBox3.Location = new System.Drawing.Point(378, -8);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(248, 192);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 49;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::SeitonSystem.Properties.Resources.chocEscorrendo;
            this.pictureBox2.Location = new System.Drawing.Point(-4, 35);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1002, 149);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 48;
            this.pictureBox2.TabStop = false;
            // 
            // InicialView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(156)))), ((int)(((byte)(154)))));
            this.ClientSize = new System.Drawing.Size(996, 814);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dt);
            this.Controls.Add(this.btn_financas);
            this.Controls.Add(this.btn_pedido);
            this.Controls.Add(this.btn_produtos);
            this.Controls.Add(this.btn_clientes);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "InicialView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bem-Vindo ao Seiton System";
            this.Load += new System.EventHandler(this.InicialView_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btn_financas;
        private System.Windows.Forms.Button btn_pedido;
        private System.Windows.Forms.Button btn_produtos;
        private System.Windows.Forms.Button btn_clientes;
        private System.Windows.Forms.Button btn_tbPedidos;
        private System.Windows.Forms.Button btn_Add_Produto;
        private System.Windows.Forms.Button btn_add_cliente;
        private System.Windows.Forms.Button btn_finançasView;
        private System.Windows.Forms.Button btn_bakup;
        private MetroFramework.Controls.MetroGrid dt;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel linha;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label_percent;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_ajuda;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btn_abrir_manual;
        private System.Windows.Forms.TextBox txt_lucro;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_financasCadastrar;
    }
}