﻿namespace SeitonSystem.src.view.pedido
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_produto = new System.Windows.Forms.Panel();
            this.lbl_pedido = new System.Windows.Forms.Button();
            this.btn_addProd = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.pic_passoUm = new System.Windows.Forms.PictureBox();
            this.pic_passoDois = new System.Windows.Forms.PictureBox();
            this.lbl_obs = new System.Windows.Forms.Label();
            this.txt_obs = new System.Windows.Forms.TextBox();
            this.lbl_qtd = new System.Windows.Forms.Label();
            this.txt_quantidade = new System.Windows.Forms.NumericUpDown();
            this.cb_produtos = new System.Windows.Forms.ComboBox();
            this.lbl_produto = new System.Windows.Forms.Label();
            this.txt_valorTotal = new System.Windows.Forms.TextBox();
            this.lbl_valor = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox = new System.Windows.Forms.TextBox();
            this.db_produtos = new MetroFramework.Controls.MetroGrid();
            this.panel_produtos = new System.Windows.Forms.Panel();
            this.btn_excluir = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_proximo = new System.Windows.Forms.PictureBox();
            this.panel = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pic_passoTres = new System.Windows.Forms.PictureBox();
            this.panel_produto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoDois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_quantidade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtos)).BeginInit();
            this.panel_produtos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_produto
            // 
            this.panel_produto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_produto.Controls.Add(this.lbl_pedido);
            this.panel_produto.Controls.Add(this.btn_addProd);
            this.panel_produto.Controls.Add(this.btn_limpar);
            this.panel_produto.Controls.Add(this.pic_passoUm);
            this.panel_produto.Controls.Add(this.pic_passoDois);
            this.panel_produto.Controls.Add(this.lbl_obs);
            this.panel_produto.Controls.Add(this.txt_obs);
            this.panel_produto.Controls.Add(this.lbl_qtd);
            this.panel_produto.Controls.Add(this.txt_quantidade);
            this.panel_produto.Controls.Add(this.cb_produtos);
            this.panel_produto.Controls.Add(this.lbl_produto);
            this.panel_produto.Controls.Add(this.txt_valorTotal);
            this.panel_produto.Controls.Add(this.lbl_valor);
            this.panel_produto.Controls.Add(this.label9);
            this.panel_produto.Controls.Add(this.textBox);
            this.panel_produto.Controls.Add(this.db_produtos);
            this.panel_produto.Controls.Add(this.panel_produtos);
            this.panel_produto.Controls.Add(this.panel4);
            this.panel_produto.Controls.Add(this.btn_proximo);
            this.panel_produto.Controls.Add(this.panel);
            this.panel_produto.Controls.Add(this.panel5);
            this.panel_produto.Controls.Add(this.pic_passoTres);
            this.panel_produto.Location = new System.Drawing.Point(50, 37);
            this.panel_produto.Margin = new System.Windows.Forms.Padding(4);
            this.panel_produto.Name = "panel_produto";
            this.panel_produto.Size = new System.Drawing.Size(947, 426);
            this.panel_produto.TabIndex = 22;
            // 
            // lbl_pedido
            // 
            this.lbl_pedido.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_pedido.FlatAppearance.BorderSize = 0;
            this.lbl_pedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_pedido.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedido.ForeColor = System.Drawing.Color.White;
            this.lbl_pedido.Location = new System.Drawing.Point(16, 8);
            this.lbl_pedido.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_pedido.Name = "lbl_pedido";
            this.lbl_pedido.Size = new System.Drawing.Size(313, 47);
            this.lbl_pedido.TabIndex = 23;
            this.lbl_pedido.Text = "Pedido";
            this.lbl_pedido.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_pedido.UseVisualStyleBackColor = false;
            // 
            // btn_addProd
            // 
            this.btn_addProd.BackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_add;
            this.btn_addProd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_addProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_addProd.FlatAppearance.BorderSize = 0;
            this.btn_addProd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addProd.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.btn_addProd.ForeColor = System.Drawing.Color.White;
            this.btn_addProd.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_addProd.Location = new System.Drawing.Point(720, 284);
            this.btn_addProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_addProd.Name = "btn_addProd";
            this.btn_addProd.Size = new System.Drawing.Size(151, 38);
            this.btn_addProd.TabIndex = 98;
            this.btn_addProd.Text = "        Adicionar ";
            this.btn_addProd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_addProd.UseVisualStyleBackColor = false;
            this.btn_addProd.Visible = false;
            // 
            // btn_limpar
            // 
            this.btn_limpar.BackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_limpar.FlatAppearance.BorderSize = 0;
            this.btn_limpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_limpar.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpar.ForeColor = System.Drawing.Color.Black;
            this.btn_limpar.Image = global::SeitonSystem.Properties.Resources.icone_deletar;
            this.btn_limpar.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_limpar.Location = new System.Drawing.Point(647, 284);
            this.btn_limpar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(43, 37);
            this.btn_limpar.TabIndex = 97;
            this.btn_limpar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_limpar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_limpar.UseVisualStyleBackColor = false;
            this.btn_limpar.Visible = false;
            // 
            // pic_passoUm
            // 
            this.pic_passoUm.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_umSelect;
            this.pic_passoUm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoUm.Location = new System.Drawing.Point(713, 7);
            this.pic_passoUm.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoUm.Name = "pic_passoUm";
            this.pic_passoUm.Size = new System.Drawing.Size(53, 49);
            this.pic_passoUm.TabIndex = 96;
            this.pic_passoUm.TabStop = false;
            // 
            // pic_passoDois
            // 
            this.pic_passoDois.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_dois;
            this.pic_passoDois.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoDois.Location = new System.Drawing.Point(773, 11);
            this.pic_passoDois.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoDois.Name = "pic_passoDois";
            this.pic_passoDois.Size = new System.Drawing.Size(48, 44);
            this.pic_passoDois.TabIndex = 95;
            this.pic_passoDois.TabStop = false;
            // 
            // lbl_obs
            // 
            this.lbl_obs.BackColor = System.Drawing.Color.Transparent;
            this.lbl_obs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_obs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_obs.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_obs.ForeColor = System.Drawing.Color.White;
            this.lbl_obs.Location = new System.Drawing.Point(647, 146);
            this.lbl_obs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_obs.Name = "lbl_obs";
            this.lbl_obs.Size = new System.Drawing.Size(224, 30);
            this.lbl_obs.TabIndex = 94;
            this.lbl_obs.Text = "Observação:";
            this.lbl_obs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_obs
            // 
            this.txt_obs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_obs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_obs.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_obs.ForeColor = System.Drawing.Color.White;
            this.txt_obs.Location = new System.Drawing.Point(647, 177);
            this.txt_obs.Margin = new System.Windows.Forms.Padding(4);
            this.txt_obs.MaxLength = 9999;
            this.txt_obs.Multiline = true;
            this.txt_obs.Name = "txt_obs";
            this.txt_obs.ReadOnly = true;
            this.txt_obs.Size = new System.Drawing.Size(223, 100);
            this.txt_obs.TabIndex = 93;
            // 
            // lbl_qtd
            // 
            this.lbl_qtd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_qtd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_qtd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_qtd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_qtd.ForeColor = System.Drawing.Color.White;
            this.lbl_qtd.Location = new System.Drawing.Point(649, 87);
            this.lbl_qtd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_qtd.Name = "lbl_qtd";
            this.lbl_qtd.Size = new System.Drawing.Size(139, 28);
            this.lbl_qtd.TabIndex = 89;
            this.lbl_qtd.Text = "*Quantidade:";
            this.lbl_qtd.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_quantidade
            // 
            this.txt_quantidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_quantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_quantidade.Font = new System.Drawing.Font("Segoe UI", 13.25F);
            this.txt_quantidade.ForeColor = System.Drawing.Color.White;
            this.txt_quantidade.Location = new System.Drawing.Point(801, 86);
            this.txt_quantidade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_quantidade.Name = "txt_quantidade";
            this.txt_quantidade.ReadOnly = true;
            this.txt_quantidade.Size = new System.Drawing.Size(75, 33);
            this.txt_quantidade.TabIndex = 88;
            // 
            // cb_produtos
            // 
            this.cb_produtos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_produtos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_produtos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_produtos.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_produtos.ForeColor = System.Drawing.Color.White;
            this.cb_produtos.FormattingEnabled = true;
            this.cb_produtos.Location = new System.Drawing.Point(143, 82);
            this.cb_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.cb_produtos.Name = "cb_produtos";
            this.cb_produtos.Size = new System.Drawing.Size(495, 36);
            this.cb_produtos.TabIndex = 87;
            // 
            // lbl_produto
            // 
            this.lbl_produto.BackColor = System.Drawing.Color.Transparent;
            this.lbl_produto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_produto.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_produto.ForeColor = System.Drawing.Color.White;
            this.lbl_produto.Location = new System.Drawing.Point(32, 86);
            this.lbl_produto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_produto.Name = "lbl_produto";
            this.lbl_produto.Size = new System.Drawing.Size(113, 28);
            this.lbl_produto.TabIndex = 86;
            this.lbl_produto.Text = "Produtos:";
            this.lbl_produto.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_valorTotal
            // 
            this.txt_valorTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_valorTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_valorTotal.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txt_valorTotal.ForeColor = System.Drawing.Color.White;
            this.txt_valorTotal.Location = new System.Drawing.Point(448, 348);
            this.txt_valorTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_valorTotal.MaxLength = 9;
            this.txt_valorTotal.Multiline = true;
            this.txt_valorTotal.Name = "txt_valorTotal";
            this.txt_valorTotal.ReadOnly = true;
            this.txt_valorTotal.Size = new System.Drawing.Size(152, 38);
            this.txt_valorTotal.TabIndex = 85;
            this.txt_valorTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_valorTotal.WordWrap = false;
            // 
            // lbl_valor
            // 
            this.lbl_valor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_valor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_valor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_valor.ForeColor = System.Drawing.Color.White;
            this.lbl_valor.Location = new System.Drawing.Point(217, 352);
            this.lbl_valor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_valor.Name = "lbl_valor";
            this.lbl_valor.Size = new System.Drawing.Size(147, 28);
            this.lbl_valor.TabIndex = 83;
            this.lbl_valor.Text = "Valor Total:";
            this.lbl_valor.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(372, 348);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 38);
            this.label9.TabIndex = 84;
            this.label9.Text = "R$";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox
            // 
            this.textBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox.ForeColor = System.Drawing.Color.White;
            this.textBox.Location = new System.Drawing.Point(371, 345);
            this.textBox.Margin = new System.Windows.Forms.Padding(4);
            this.textBox.MaxLength = 9;
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.Size = new System.Drawing.Size(233, 45);
            this.textBox.TabIndex = 82;
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // db_produtos
            // 
            this.db_produtos.AllowUserToAddRows = false;
            this.db_produtos.AllowUserToDeleteRows = false;
            this.db_produtos.AllowUserToResizeRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.db_produtos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.db_produtos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(215)))), ((int)(((byte)(214)))));
            this.db_produtos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.db_produtos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.db_produtos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.db_produtos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.db_produtos.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.db_produtos.DefaultCellStyle = dataGridViewCellStyle8;
            this.db_produtos.EnableHeadersVisualStyles = false;
            this.db_produtos.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.db_produtos.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.db_produtos.Location = new System.Drawing.Point(39, 137);
            this.db_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.db_produtos.Name = "db_produtos";
            this.db_produtos.ReadOnly = true;
            this.db_produtos.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtos.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.db_produtos.RowHeadersWidth = 51;
            this.db_produtos.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.db_produtos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.db_produtos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.db_produtos.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.db_produtos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            this.db_produtos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.db_produtos.Size = new System.Drawing.Size(596, 178);
            this.db_produtos.TabIndex = 81;
            // 
            // panel_produtos
            // 
            this.panel_produtos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_produtos.BackgroundImage = global::SeitonSystem.Properties.Resources.retangulo;
            this.panel_produtos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_produtos.Controls.Add(this.btn_excluir);
            this.panel_produtos.Location = new System.Drawing.Point(16, 311);
            this.panel_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.panel_produtos.Name = "panel_produtos";
            this.panel_produtos.Size = new System.Drawing.Size(152, 66);
            this.panel_produtos.TabIndex = 80;
            this.panel_produtos.Visible = false;
            // 
            // btn_excluir
            // 
            this.btn_excluir.BackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_excluir.FlatAppearance.BorderSize = 0;
            this.btn_excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_excluir.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_excluir.ForeColor = System.Drawing.Color.Black;
            this.btn_excluir.Image = global::SeitonSystem.Properties.Resources.icone_deletar;
            this.btn_excluir.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_excluir.Location = new System.Drawing.Point(17, 15);
            this.btn_excluir.Margin = new System.Windows.Forms.Padding(4);
            this.btn_excluir.Name = "btn_excluir";
            this.btn_excluir.Size = new System.Drawing.Size(121, 39);
            this.btn_excluir.TabIndex = 39;
            this.btn_excluir.Text = "Deletar";
            this.btn_excluir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_excluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_excluir.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(636, 140);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 182);
            this.panel4.TabIndex = 79;
            // 
            // btn_proximo
            // 
            this.btn_proximo.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_prox;
            this.btn_proximo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_proximo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_proximo.Location = new System.Drawing.Point(735, 342);
            this.btn_proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_proximo.Name = "btn_proximo";
            this.btn_proximo.Size = new System.Drawing.Size(143, 62);
            this.btn_proximo.TabIndex = 21;
            this.btn_proximo.TabStop = false;
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(215)))), ((int)(((byte)(214)))));
            this.panel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.panel.ForeColor = System.Drawing.Color.White;
            this.panel.Location = new System.Drawing.Point(631, 137);
            this.panel.Margin = new System.Windows.Forms.Padding(4);
            this.panel.MaxLength = 9;
            this.panel.Multiline = true;
            this.panel.Name = "panel";
            this.panel.ReadOnly = true;
            this.panel.Size = new System.Drawing.Size(245, 194);
            this.panel.TabIndex = 78;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(27, 63);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(867, 2);
            this.panel5.TabIndex = 22;
            // 
            // pic_passoTres
            // 
            this.pic_passoTres.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_tres;
            this.pic_passoTres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoTres.Location = new System.Drawing.Point(828, 11);
            this.pic_passoTres.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoTres.Name = "pic_passoTres";
            this.pic_passoTres.Size = new System.Drawing.Size(48, 44);
            this.pic_passoTres.TabIndex = 18;
            this.pic_passoTres.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1328, 703);
            this.Controls.Add(this.panel_produto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_produto.ResumeLayout(false);
            this.panel_produto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoDois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_quantidade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtos)).EndInit();
            this.panel_produtos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_produto;
        private System.Windows.Forms.Button lbl_pedido;
        private System.Windows.Forms.Button btn_addProd;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.PictureBox pic_passoUm;
        private System.Windows.Forms.PictureBox pic_passoDois;
        private System.Windows.Forms.Label lbl_obs;
        private System.Windows.Forms.TextBox txt_obs;
        private System.Windows.Forms.Label lbl_qtd;
        private System.Windows.Forms.NumericUpDown txt_quantidade;
        private System.Windows.Forms.ComboBox cb_produtos;
        private System.Windows.Forms.Label lbl_produto;
        private System.Windows.Forms.TextBox txt_valorTotal;
        private System.Windows.Forms.Label lbl_valor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox;
        private MetroFramework.Controls.MetroGrid db_produtos;
        private System.Windows.Forms.Panel panel_produtos;
        private System.Windows.Forms.Button btn_excluir;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox btn_proximo;
        private System.Windows.Forms.TextBox panel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pic_passoTres;
    }
}