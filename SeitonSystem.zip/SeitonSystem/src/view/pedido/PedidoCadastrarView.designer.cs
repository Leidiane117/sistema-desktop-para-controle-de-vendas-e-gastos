﻿namespace SeitonSystem.src.view.Pedido
{
    partial class PedidoCadastrarView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PedidoCadastrarView));
            this.btn_pedido = new System.Windows.Forms.Button();
            this.btn_produtos = new System.Windows.Forms.Button();
            this.btn_clientes = new System.Windows.Forms.Button();
            this.panel_cliente = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.lbl_dataPag = new System.Windows.Forms.Label();
            this.btn_proximoDois = new System.Windows.Forms.PictureBox();
            this.pic_passoUm2 = new System.Windows.Forms.PictureBox();
            this.pc_passoDois2 = new System.Windows.Forms.PictureBox();
            this.btn_anterior = new System.Windows.Forms.PictureBox();
            this.cb_tipoPedido = new System.Windows.Forms.ComboBox();
            this.lbl_tpPedido = new System.Windows.Forms.Label();
            this.cb_tipoPag = new System.Windows.Forms.ComboBox();
            this.txt_horaEntrega = new System.Windows.Forms.DateTimePicker();
            this.txt_dataPag = new System.Windows.Forms.DateTimePicker();
            this.txt_dataEntrega = new System.Windows.Forms.DateTimePicker();
            this.lbl_tipo = new System.Windows.Forms.Label();
            this.lbl_HoraEntrega = new System.Windows.Forms.Label();
            this.lbl_dataEntrega = new System.Windows.Forms.Label();
            this.cb_situacao = new System.Windows.Forms.ComboBox();
            this.lbl_situacao = new System.Windows.Forms.Label();
            this.cb_cliente = new System.Windows.Forms.ComboBox();
            this.lbl_cliente = new System.Windows.Forms.Label();
            this.lbl_pedidoDois = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pic_passoTres4 = new System.Windows.Forms.PictureBox();
            this.btn_proximoDoisE = new System.Windows.Forms.PictureBox();
            this.panel_endereco = new System.Windows.Forms.Panel();
            this.btn_proximoTres = new System.Windows.Forms.PictureBox();
            this.lbl_endereco = new System.Windows.Forms.Button();
            this.lbl_compl = new System.Windows.Forms.Label();
            this.lbl_uf = new System.Windows.Forms.Label();
            this.lbl_cidade = new System.Windows.Forms.Label();
            this.lbl_cep = new System.Windows.Forms.Label();
            this.lbl_num = new System.Windows.Forms.Label();
            this.lbl_bairro = new System.Windows.Forms.Label();
            this.lbl_logradouro = new System.Windows.Forms.Label();
            this.txt_logradouro = new System.Windows.Forms.TextBox();
            this.txt_bairro = new System.Windows.Forms.TextBox();
            this.txt_cep = new System.Windows.Forms.TextBox();
            this.txt_compl = new System.Windows.Forms.TextBox();
            this.txt_uf = new System.Windows.Forms.TextBox();
            this.txt_cidade = new System.Windows.Forms.TextBox();
            this.txt_num = new System.Windows.Forms.TextBox();
            this.pc_passoDois3 = new System.Windows.Forms.PictureBox();
            this.pc_passoTres3 = new System.Windows.Forms.PictureBox();
            this.btn_anteriorDois = new System.Windows.Forms.PictureBox();
            this.pc_passoUm3 = new System.Windows.Forms.PictureBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lbl_pedidoTres = new System.Windows.Forms.Button();
            this.panel_enderecoV = new System.Windows.Forms.Panel();
            this.lbl_complV = new System.Windows.Forms.Label();
            this.lbl_ufV = new System.Windows.Forms.Label();
            this.lbl_cidadeV = new System.Windows.Forms.Label();
            this.lbl_cepV = new System.Windows.Forms.Label();
            this.lbl_numV = new System.Windows.Forms.Label();
            this.lbl_bairroV = new System.Windows.Forms.Label();
            this.lbl_log = new System.Windows.Forms.Label();
            this.txt_logradouroV = new System.Windows.Forms.TextBox();
            this.txt_bairroV = new System.Windows.Forms.TextBox();
            this.txt_cepV = new System.Windows.Forms.TextBox();
            this.txt_complV = new System.Windows.Forms.TextBox();
            this.txt_ufV = new System.Windows.Forms.TextBox();
            this.txt_cidadeV = new System.Windows.Forms.TextBox();
            this.txt_numV = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel_pedido = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_valorTotalV = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.btn_anteriorTres = new System.Windows.Forms.PictureBox();
            this.btn_cadastrar = new System.Windows.Forms.PictureBox();
            this.txt_clienteV = new System.Windows.Forms.TextBox();
            this.db_produtosV = new MetroFramework.Controls.MetroGrid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_produtoV = new System.Windows.Forms.Label();
            this.cb_tipoPedidoV = new System.Windows.Forms.ComboBox();
            this.lbl_tipoPedidoV = new System.Windows.Forms.Label();
            this.cb_tipoPagV = new System.Windows.Forms.ComboBox();
            this.txt_horaEntregaV = new System.Windows.Forms.DateTimePicker();
            this.txt_dataPagV = new System.Windows.Forms.DateTimePicker();
            this.txt_dataEntregaV = new System.Windows.Forms.DateTimePicker();
            this.lbl_dataPagV = new System.Windows.Forms.Label();
            this.lbl_tipoPagV = new System.Windows.Forms.Label();
            this.lbl_horaEntregaV = new System.Windows.Forms.Label();
            this.lbl_dataEntregaV = new System.Windows.Forms.Label();
            this.cb_situacaoV = new System.Windows.Forms.ComboBox();
            this.lbl_situacaoV = new System.Windows.Forms.Label();
            this.lbl_clienteV = new System.Windows.Forms.Label();
            this.lbl_tituloV = new System.Windows.Forms.Button();
            this.panel_produto = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.lbl_pedido = new System.Windows.Forms.Button();
            this.btn_addProd = new System.Windows.Forms.Button();
            this.btn_limpar = new System.Windows.Forms.Button();
            this.pic_passoUm = new System.Windows.Forms.PictureBox();
            this.pic_passoDois = new System.Windows.Forms.PictureBox();
            this.lbl_obs = new System.Windows.Forms.Label();
            this.txt_obs = new System.Windows.Forms.TextBox();
            this.lbl_qtd = new System.Windows.Forms.Label();
            this.txt_quantidade = new System.Windows.Forms.NumericUpDown();
            this.cb_produtos = new System.Windows.Forms.ComboBox();
            this.lbl_produto = new System.Windows.Forms.Label();
            this.txt_valorTotal = new System.Windows.Forms.TextBox();
            this.lbl_valor = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox = new System.Windows.Forms.TextBox();
            this.db_produtos = new MetroFramework.Controls.MetroGrid();
            this.panel_produtos = new System.Windows.Forms.Panel();
            this.btn_excluir = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btn_proximo = new System.Windows.Forms.PictureBox();
            this.panel = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pic_passoTres = new System.Windows.Forms.PictureBox();
            this.btn_financas = new System.Windows.Forms.Button();
            this.pic_cantoe = new System.Windows.Forms.PictureBox();
            this.pic_caldaE = new System.Windows.Forms.PictureBox();
            this.pic_cantod = new System.Windows.Forms.PictureBox();
            this.pic_caldaD = new System.Windows.Forms.PictureBox();
            this.pic_logo = new System.Windows.Forms.PictureBox();
            this.pic_calda = new System.Windows.Forms.PictureBox();
            this.panel_cliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoDois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoDois2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anterior)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoDoisE)).BeginInit();
            this.panel_endereco.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoTres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoDois3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoTres3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anteriorDois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoUm3)).BeginInit();
            this.panel_enderecoV.SuspendLayout();
            this.panel_pedido.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anteriorTres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cadastrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtosV)).BeginInit();
            this.panel_produto.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoDois)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_quantidade)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtos)).BeginInit();
            this.panel_produtos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cantoe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_caldaE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cantod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_caldaD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_calda)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_pedido
            // 
            this.btn_pedido.BackColor = System.Drawing.Color.White;
            this.btn_pedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_pedido.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_pedido.FlatAppearance.BorderSize = 0;
            this.btn_pedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_pedido.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_pedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_pedido.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pedido.Location = new System.Drawing.Point(743, 0);
            this.btn_pedido.Margin = new System.Windows.Forms.Padding(4);
            this.btn_pedido.Name = "btn_pedido";
            this.btn_pedido.Size = new System.Drawing.Size(220, 38);
            this.btn_pedido.TabIndex = 11;
            this.btn_pedido.Text = "Pedidos";
            this.btn_pedido.UseVisualStyleBackColor = false;
            this.btn_pedido.Click += new System.EventHandler(this.btn_pedido_Click);
            // 
            // btn_produtos
            // 
            this.btn_produtos.BackColor = System.Drawing.Color.White;
            this.btn_produtos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_produtos.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_produtos.FlatAppearance.BorderSize = 0;
            this.btn_produtos.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_produtos.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_produtos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_produtos.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_produtos.Location = new System.Drawing.Point(357, 0);
            this.btn_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.btn_produtos.Name = "btn_produtos";
            this.btn_produtos.Size = new System.Drawing.Size(209, 38);
            this.btn_produtos.TabIndex = 10;
            this.btn_produtos.Text = "Produtos";
            this.btn_produtos.UseVisualStyleBackColor = false;
            this.btn_produtos.Click += new System.EventHandler(this.btn_produtos_Click);
            // 
            // btn_clientes
            // 
            this.btn_clientes.BackColor = System.Drawing.Color.White;
            this.btn_clientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_clientes.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_clientes.FlatAppearance.BorderSize = 0;
            this.btn_clientes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_clientes.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_clientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_clientes.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_clientes.Location = new System.Drawing.Point(157, 0);
            this.btn_clientes.Margin = new System.Windows.Forms.Padding(4);
            this.btn_clientes.Name = "btn_clientes";
            this.btn_clientes.Size = new System.Drawing.Size(201, 38);
            this.btn_clientes.TabIndex = 9;
            this.btn_clientes.Text = "Clientes";
            this.btn_clientes.UseVisualStyleBackColor = false;
            this.btn_clientes.Click += new System.EventHandler(this.btn_clientes_Click);
            // 
            // panel_cliente
            // 
            this.panel_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_cliente.Controls.Add(this.button2);
            this.panel_cliente.Controls.Add(this.lbl_dataPag);
            this.panel_cliente.Controls.Add(this.btn_proximoDois);
            this.panel_cliente.Controls.Add(this.pic_passoUm2);
            this.panel_cliente.Controls.Add(this.pc_passoDois2);
            this.panel_cliente.Controls.Add(this.btn_anterior);
            this.panel_cliente.Controls.Add(this.cb_tipoPedido);
            this.panel_cliente.Controls.Add(this.lbl_tpPedido);
            this.panel_cliente.Controls.Add(this.cb_tipoPag);
            this.panel_cliente.Controls.Add(this.txt_horaEntrega);
            this.panel_cliente.Controls.Add(this.txt_dataPag);
            this.panel_cliente.Controls.Add(this.txt_dataEntrega);
            this.panel_cliente.Controls.Add(this.lbl_tipo);
            this.panel_cliente.Controls.Add(this.lbl_HoraEntrega);
            this.panel_cliente.Controls.Add(this.lbl_dataEntrega);
            this.panel_cliente.Controls.Add(this.cb_situacao);
            this.panel_cliente.Controls.Add(this.lbl_situacao);
            this.panel_cliente.Controls.Add(this.cb_cliente);
            this.panel_cliente.Controls.Add(this.lbl_cliente);
            this.panel_cliente.Controls.Add(this.lbl_pedidoDois);
            this.panel_cliente.Controls.Add(this.panel2);
            this.panel_cliente.Controls.Add(this.pic_passoTres4);
            this.panel_cliente.Controls.Add(this.btn_proximoDoisE);
            this.panel_cliente.Location = new System.Drawing.Point(75, 10);
            this.panel_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.panel_cliente.Name = "panel_cliente";
            this.panel_cliente.Size = new System.Drawing.Size(992, 353);
            this.panel_cliente.TabIndex = 15;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_add;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(208, 302);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(219, 38);
            this.button2.TabIndex = 100;
            this.button2.Text = "        Adicionar novo Cliente";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_dataPag
            // 
            this.lbl_dataPag.BackColor = System.Drawing.Color.Transparent;
            this.lbl_dataPag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_dataPag.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_dataPag.ForeColor = System.Drawing.Color.White;
            this.lbl_dataPag.Location = new System.Drawing.Point(608, 185);
            this.lbl_dataPag.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dataPag.Name = "lbl_dataPag";
            this.lbl_dataPag.Size = new System.Drawing.Size(281, 28);
            this.lbl_dataPag.TabIndex = 81;
            this.lbl_dataPag.Text = "*Data de Pagamento:";
            this.lbl_dataPag.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // btn_proximoDois
            // 
            this.btn_proximoDois.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_prox;
            this.btn_proximoDois.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_proximoDois.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_proximoDois.Location = new System.Drawing.Point(733, 278);
            this.btn_proximoDois.Margin = new System.Windows.Forms.Padding(4);
            this.btn_proximoDois.Name = "btn_proximoDois";
            this.btn_proximoDois.Size = new System.Drawing.Size(143, 62);
            this.btn_proximoDois.TabIndex = 98;
            this.btn_proximoDois.TabStop = false;
            this.btn_proximoDois.Visible = false;
            this.btn_proximoDois.Click += new System.EventHandler(this.btn_proximoDois_Click);
            // 
            // pic_passoUm2
            // 
            this.pic_passoUm2.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_um;
            this.pic_passoUm2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoUm2.Location = new System.Drawing.Point(713, 11);
            this.pic_passoUm2.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoUm2.Name = "pic_passoUm2";
            this.pic_passoUm2.Size = new System.Drawing.Size(48, 44);
            this.pic_passoUm2.TabIndex = 97;
            this.pic_passoUm2.TabStop = false;
            // 
            // pc_passoDois2
            // 
            this.pc_passoDois2.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_doisSelect;
            this.pc_passoDois2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pc_passoDois2.Location = new System.Drawing.Point(769, 9);
            this.pc_passoDois2.Margin = new System.Windows.Forms.Padding(4);
            this.pc_passoDois2.Name = "pc_passoDois2";
            this.pc_passoDois2.Size = new System.Drawing.Size(53, 49);
            this.pc_passoDois2.TabIndex = 96;
            this.pc_passoDois2.TabStop = false;
            // 
            // btn_anterior
            // 
            this.btn_anterior.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_ant;
            this.btn_anterior.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_anterior.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_anterior.Location = new System.Drawing.Point(40, 278);
            this.btn_anterior.Margin = new System.Windows.Forms.Padding(4);
            this.btn_anterior.Name = "btn_anterior";
            this.btn_anterior.Size = new System.Drawing.Size(143, 62);
            this.btn_anterior.TabIndex = 89;
            this.btn_anterior.TabStop = false;
            this.btn_anterior.Click += new System.EventHandler(this.btn_anterior_Click);
            // 
            // cb_tipoPedido
            // 
            this.cb_tipoPedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_tipoPedido.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_tipoPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_tipoPedido.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_tipoPedido.ForeColor = System.Drawing.Color.Gray;
            this.cb_tipoPedido.FormattingEnabled = true;
            this.cb_tipoPedido.Items.AddRange(new object[] {
            "Entrega",
            "Retirada"});
            this.cb_tipoPedido.Location = new System.Drawing.Point(208, 139);
            this.cb_tipoPedido.Margin = new System.Windows.Forms.Padding(4);
            this.cb_tipoPedido.Name = "cb_tipoPedido";
            this.cb_tipoPedido.Size = new System.Drawing.Size(225, 36);
            this.cb_tipoPedido.TabIndex = 88;
            this.cb_tipoPedido.SelectedIndexChanged += new System.EventHandler(this.cb_tipoPedido_SelectedIndexChanged);
            // 
            // lbl_tpPedido
            // 
            this.lbl_tpPedido.BackColor = System.Drawing.Color.Transparent;
            this.lbl_tpPedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_tpPedido.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_tpPedido.ForeColor = System.Drawing.Color.White;
            this.lbl_tpPedido.Location = new System.Drawing.Point(33, 143);
            this.lbl_tpPedido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_tpPedido.Name = "lbl_tpPedido";
            this.lbl_tpPedido.Size = new System.Drawing.Size(192, 28);
            this.lbl_tpPedido.TabIndex = 87;
            this.lbl_tpPedido.Text = "*Tipo de Pedido:";
            this.lbl_tpPedido.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_tipoPag
            // 
            this.cb_tipoPag.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_tipoPag.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_tipoPag.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_tipoPag.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_tipoPag.ForeColor = System.Drawing.Color.DimGray;
            this.cb_tipoPag.FormattingEnabled = true;
            this.cb_tipoPag.Items.AddRange(new object[] {
            "Dinheiro",
            "Cartão"});
            this.cb_tipoPag.Location = new System.Drawing.Point(649, 139);
            this.cb_tipoPag.Margin = new System.Windows.Forms.Padding(4);
            this.cb_tipoPag.Name = "cb_tipoPag";
            this.cb_tipoPag.Size = new System.Drawing.Size(225, 36);
            this.cb_tipoPag.TabIndex = 85;
            // 
            // txt_horaEntrega
            // 
            this.txt_horaEntrega.CalendarFont = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_horaEntrega.CalendarForeColor = System.Drawing.Color.White;
            this.txt_horaEntrega.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_horaEntrega.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_horaEntrega.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_horaEntrega.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_horaEntrega.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_horaEntrega.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.txt_horaEntrega.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txt_horaEntrega.Location = new System.Drawing.Point(324, 215);
            this.txt_horaEntrega.Margin = new System.Windows.Forms.Padding(4);
            this.txt_horaEntrega.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_horaEntrega.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_horaEntrega.Name = "txt_horaEntrega";
            this.txt_horaEntrega.ShowUpDown = true;
            this.txt_horaEntrega.Size = new System.Drawing.Size(261, 30);
            this.txt_horaEntrega.TabIndex = 84;
            this.txt_horaEntrega.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // txt_dataPag
            // 
            this.txt_dataPag.CalendarFont = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataPag.CalendarForeColor = System.Drawing.Color.White;
            this.txt_dataPag.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_dataPag.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_dataPag.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_dataPag.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_dataPag.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataPag.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_dataPag.Location = new System.Drawing.Point(613, 215);
            this.txt_dataPag.Margin = new System.Windows.Forms.Padding(4);
            this.txt_dataPag.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_dataPag.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_dataPag.Name = "txt_dataPag";
            this.txt_dataPag.Size = new System.Drawing.Size(261, 30);
            this.txt_dataPag.TabIndex = 83;
            this.txt_dataPag.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // txt_dataEntrega
            // 
            this.txt_dataEntrega.CalendarFont = new System.Drawing.Font("Segoe UI", 11.25F);
            this.txt_dataEntrega.CalendarForeColor = System.Drawing.Color.White;
            this.txt_dataEntrega.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_dataEntrega.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_dataEntrega.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_dataEntrega.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_dataEntrega.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataEntrega.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_dataEntrega.Location = new System.Drawing.Point(36, 215);
            this.txt_dataEntrega.Margin = new System.Windows.Forms.Padding(4);
            this.txt_dataEntrega.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_dataEntrega.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_dataEntrega.Name = "txt_dataEntrega";
            this.txt_dataEntrega.Size = new System.Drawing.Size(261, 30);
            this.txt_dataEntrega.TabIndex = 82;
            this.txt_dataEntrega.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // lbl_tipo
            // 
            this.lbl_tipo.BackColor = System.Drawing.Color.Transparent;
            this.lbl_tipo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_tipo.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tipo.ForeColor = System.Drawing.Color.White;
            this.lbl_tipo.Location = new System.Drawing.Point(445, 143);
            this.lbl_tipo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_tipo.Name = "lbl_tipo";
            this.lbl_tipo.Size = new System.Drawing.Size(236, 28);
            this.lbl_tipo.TabIndex = 80;
            this.lbl_tipo.Text = "*Tipo de Pagamento:";
            this.lbl_tipo.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_HoraEntrega
            // 
            this.lbl_HoraEntrega.BackColor = System.Drawing.Color.Transparent;
            this.lbl_HoraEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_HoraEntrega.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_HoraEntrega.ForeColor = System.Drawing.Color.White;
            this.lbl_HoraEntrega.Location = new System.Drawing.Point(321, 183);
            this.lbl_HoraEntrega.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_HoraEntrega.Name = "lbl_HoraEntrega";
            this.lbl_HoraEntrega.Size = new System.Drawing.Size(193, 28);
            this.lbl_HoraEntrega.TabIndex = 79;
            this.lbl_HoraEntrega.Text = "*Hora de Entrega:";
            this.lbl_HoraEntrega.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_dataEntrega
            // 
            this.lbl_dataEntrega.BackColor = System.Drawing.Color.Transparent;
            this.lbl_dataEntrega.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_dataEntrega.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dataEntrega.ForeColor = System.Drawing.Color.White;
            this.lbl_dataEntrega.Location = new System.Drawing.Point(35, 185);
            this.lbl_dataEntrega.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dataEntrega.Name = "lbl_dataEntrega";
            this.lbl_dataEntrega.Size = new System.Drawing.Size(193, 28);
            this.lbl_dataEntrega.TabIndex = 78;
            this.lbl_dataEntrega.Text = "*Data de Entrega:";
            this.lbl_dataEntrega.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_situacao
            // 
            this.cb_situacao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_situacao.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_situacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_situacao.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_situacao.ForeColor = System.Drawing.Color.DimGray;
            this.cb_situacao.FormattingEnabled = true;
            this.cb_situacao.Items.AddRange(new object[] {
            "Pendente",
            "Em Andamento"});
            this.cb_situacao.Location = new System.Drawing.Point(704, 84);
            this.cb_situacao.Margin = new System.Windows.Forms.Padding(4);
            this.cb_situacao.Name = "cb_situacao";
            this.cb_situacao.Size = new System.Drawing.Size(169, 36);
            this.cb_situacao.TabIndex = 46;
            // 
            // lbl_situacao
            // 
            this.lbl_situacao.BackColor = System.Drawing.Color.Transparent;
            this.lbl_situacao.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_situacao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_situacao.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_situacao.ForeColor = System.Drawing.Color.White;
            this.lbl_situacao.Location = new System.Drawing.Point(608, 87);
            this.lbl_situacao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_situacao.Name = "lbl_situacao";
            this.lbl_situacao.Size = new System.Drawing.Size(101, 28);
            this.lbl_situacao.TabIndex = 45;
            this.lbl_situacao.Text = "Situação:";
            this.lbl_situacao.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_cliente
            // 
            this.cb_cliente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_cliente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_cliente.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_cliente.ForeColor = System.Drawing.Color.DimGray;
            this.cb_cliente.FormattingEnabled = true;
            this.cb_cliente.Location = new System.Drawing.Point(128, 84);
            this.cb_cliente.Margin = new System.Windows.Forms.Padding(4);
            this.cb_cliente.Name = "cb_cliente";
            this.cb_cliente.Size = new System.Drawing.Size(469, 36);
            this.cb_cliente.TabIndex = 44;
            // 
            // lbl_cliente
            // 
            this.lbl_cliente.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_cliente.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_cliente.ForeColor = System.Drawing.Color.White;
            this.lbl_cliente.Location = new System.Drawing.Point(33, 87);
            this.lbl_cliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cliente.Name = "lbl_cliente";
            this.lbl_cliente.Size = new System.Drawing.Size(112, 28);
            this.lbl_cliente.TabIndex = 42;
            this.lbl_cliente.Text = "*Cliente:";
            this.lbl_cliente.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_pedidoDois
            // 
            this.lbl_pedidoDois.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoDois.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_pedidoDois.FlatAppearance.BorderSize = 0;
            this.lbl_pedidoDois.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoDois.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoDois.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_pedidoDois.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedidoDois.ForeColor = System.Drawing.Color.White;
            this.lbl_pedidoDois.Location = new System.Drawing.Point(23, 15);
            this.lbl_pedidoDois.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_pedidoDois.Name = "lbl_pedidoDois";
            this.lbl_pedidoDois.Size = new System.Drawing.Size(313, 47);
            this.lbl_pedidoDois.TabIndex = 23;
            this.lbl_pedidoDois.TabStop = false;
            this.lbl_pedidoDois.Text = "Pedido";
            this.lbl_pedidoDois.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_pedidoDois.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(27, 63);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(867, 2);
            this.panel2.TabIndex = 22;
            // 
            // pic_passoTres4
            // 
            this.pic_passoTres4.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_tres;
            this.pic_passoTres4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoTres4.Location = new System.Drawing.Point(828, 11);
            this.pic_passoTres4.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoTres4.Name = "pic_passoTres4";
            this.pic_passoTres4.Size = new System.Drawing.Size(48, 44);
            this.pic_passoTres4.TabIndex = 18;
            this.pic_passoTres4.TabStop = false;
            // 
            // btn_proximoDoisE
            // 
            this.btn_proximoDoisE.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_prox;
            this.btn_proximoDoisE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_proximoDoisE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_proximoDoisE.Location = new System.Drawing.Point(733, 278);
            this.btn_proximoDoisE.Margin = new System.Windows.Forms.Padding(4);
            this.btn_proximoDoisE.Name = "btn_proximoDoisE";
            this.btn_proximoDoisE.Size = new System.Drawing.Size(143, 62);
            this.btn_proximoDoisE.TabIndex = 21;
            this.btn_proximoDoisE.TabStop = false;
            this.btn_proximoDoisE.Visible = false;
            this.btn_proximoDoisE.Click += new System.EventHandler(this.btn_proximoDoisE_Click);
            // 
            // panel_endereco
            // 
            this.panel_endereco.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_endereco.Controls.Add(this.btn_proximoTres);
            this.panel_endereco.Controls.Add(this.lbl_endereco);
            this.panel_endereco.Controls.Add(this.lbl_compl);
            this.panel_endereco.Controls.Add(this.lbl_uf);
            this.panel_endereco.Controls.Add(this.lbl_cidade);
            this.panel_endereco.Controls.Add(this.lbl_cep);
            this.panel_endereco.Controls.Add(this.lbl_num);
            this.panel_endereco.Controls.Add(this.lbl_bairro);
            this.panel_endereco.Controls.Add(this.lbl_logradouro);
            this.panel_endereco.Controls.Add(this.txt_logradouro);
            this.panel_endereco.Controls.Add(this.txt_bairro);
            this.panel_endereco.Controls.Add(this.txt_cep);
            this.panel_endereco.Controls.Add(this.txt_compl);
            this.panel_endereco.Controls.Add(this.txt_uf);
            this.panel_endereco.Controls.Add(this.txt_cidade);
            this.panel_endereco.Controls.Add(this.txt_num);
            this.panel_endereco.Controls.Add(this.pc_passoDois3);
            this.panel_endereco.Controls.Add(this.pc_passoTres3);
            this.panel_endereco.Controls.Add(this.btn_anteriorDois);
            this.panel_endereco.Controls.Add(this.pc_passoUm3);
            this.panel_endereco.Controls.Add(this.panel7);
            this.panel_endereco.Controls.Add(this.lbl_pedidoTres);
            this.panel_endereco.Location = new System.Drawing.Point(298, 189);
            this.panel_endereco.Margin = new System.Windows.Forms.Padding(4);
            this.panel_endereco.Name = "panel_endereco";
            this.panel_endereco.Size = new System.Drawing.Size(923, 354);
            this.panel_endereco.TabIndex = 22;
            this.panel_endereco.Visible = false;
            // 
            // btn_proximoTres
            // 
            this.btn_proximoTres.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_prox;
            this.btn_proximoTres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_proximoTres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_proximoTres.Location = new System.Drawing.Point(733, 276);
            this.btn_proximoTres.Margin = new System.Windows.Forms.Padding(4);
            this.btn_proximoTres.Name = "btn_proximoTres";
            this.btn_proximoTres.Size = new System.Drawing.Size(143, 62);
            this.btn_proximoTres.TabIndex = 119;
            this.btn_proximoTres.TabStop = false;
            this.btn_proximoTres.Click += new System.EventHandler(this.btn_proximoTres_Click);
            // 
            // lbl_endereco
            // 
            this.lbl_endereco.BackColor = System.Drawing.Color.Transparent;
            this.lbl_endereco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_endereco.FlatAppearance.BorderSize = 0;
            this.lbl_endereco.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_endereco.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_endereco.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_endereco.Font = new System.Drawing.Font("Segoe UI Semibold", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_endereco.ForeColor = System.Drawing.Color.White;
            this.lbl_endereco.Location = new System.Drawing.Point(27, 82);
            this.lbl_endereco.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_endereco.Name = "lbl_endereco";
            this.lbl_endereco.Size = new System.Drawing.Size(273, 47);
            this.lbl_endereco.TabIndex = 118;
            this.lbl_endereco.Text = "Endereço:";
            this.lbl_endereco.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_endereco.UseVisualStyleBackColor = false;
            // 
            // lbl_compl
            // 
            this.lbl_compl.BackColor = System.Drawing.Color.Transparent;
            this.lbl_compl.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_compl.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_compl.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_compl.ForeColor = System.Drawing.Color.White;
            this.lbl_compl.Location = new System.Drawing.Point(32, 204);
            this.lbl_compl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_compl.Name = "lbl_compl";
            this.lbl_compl.Size = new System.Drawing.Size(383, 28);
            this.lbl_compl.TabIndex = 117;
            this.lbl_compl.Text = "Complemento:";
            this.lbl_compl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_uf
            // 
            this.lbl_uf.BackColor = System.Drawing.Color.Transparent;
            this.lbl_uf.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_uf.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_uf.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_uf.ForeColor = System.Drawing.Color.White;
            this.lbl_uf.Location = new System.Drawing.Point(772, 204);
            this.lbl_uf.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_uf.Name = "lbl_uf";
            this.lbl_uf.Size = new System.Drawing.Size(95, 28);
            this.lbl_uf.TabIndex = 116;
            this.lbl_uf.Text = "*UF:";
            this.lbl_uf.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_cidade
            // 
            this.lbl_cidade.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cidade.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_cidade.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_cidade.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_cidade.ForeColor = System.Drawing.Color.White;
            this.lbl_cidade.Location = new System.Drawing.Point(344, 138);
            this.lbl_cidade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cidade.Name = "lbl_cidade";
            this.lbl_cidade.Size = new System.Drawing.Size(177, 28);
            this.lbl_cidade.TabIndex = 115;
            this.lbl_cidade.Text = "*Cidade:";
            this.lbl_cidade.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_cep
            // 
            this.lbl_cep.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_cep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_cep.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cep.ForeColor = System.Drawing.Color.White;
            this.lbl_cep.Location = new System.Drawing.Point(648, 137);
            this.lbl_cep.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cep.Name = "lbl_cep";
            this.lbl_cep.Size = new System.Drawing.Size(221, 28);
            this.lbl_cep.TabIndex = 114;
            this.lbl_cep.Text = "*CEP";
            this.lbl_cep.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_num
            // 
            this.lbl_num.BackColor = System.Drawing.Color.Transparent;
            this.lbl_num.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_num.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_num.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_num.ForeColor = System.Drawing.Color.White;
            this.lbl_num.Location = new System.Drawing.Point(648, 203);
            this.lbl_num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_num.Name = "lbl_num";
            this.lbl_num.Size = new System.Drawing.Size(95, 28);
            this.lbl_num.TabIndex = 113;
            this.lbl_num.Text = "*Número:";
            this.lbl_num.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_bairro
            // 
            this.lbl_bairro.BackColor = System.Drawing.Color.Transparent;
            this.lbl_bairro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_bairro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_bairro.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_bairro.ForeColor = System.Drawing.Color.White;
            this.lbl_bairro.Location = new System.Drawing.Point(33, 138);
            this.lbl_bairro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_bairro.Name = "lbl_bairro";
            this.lbl_bairro.Size = new System.Drawing.Size(228, 28);
            this.lbl_bairro.TabIndex = 112;
            this.lbl_bairro.Text = "*Bairro:";
            this.lbl_bairro.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_logradouro
            // 
            this.lbl_logradouro.BackColor = System.Drawing.Color.Transparent;
            this.lbl_logradouro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_logradouro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_logradouro.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_logradouro.ForeColor = System.Drawing.Color.White;
            this.lbl_logradouro.Location = new System.Drawing.Point(344, 69);
            this.lbl_logradouro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_logradouro.Name = "lbl_logradouro";
            this.lbl_logradouro.Size = new System.Drawing.Size(473, 28);
            this.lbl_logradouro.TabIndex = 111;
            this.lbl_logradouro.Text = "*Logradouro:";
            this.lbl_logradouro.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_logradouro
            // 
            this.txt_logradouro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_logradouro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_logradouro.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_logradouro.ForeColor = System.Drawing.Color.White;
            this.txt_logradouro.Location = new System.Drawing.Point(349, 98);
            this.txt_logradouro.Margin = new System.Windows.Forms.Padding(4);
            this.txt_logradouro.MaxLength = 9999;
            this.txt_logradouro.Multiline = true;
            this.txt_logradouro.Name = "txt_logradouro";
            this.txt_logradouro.Size = new System.Drawing.Size(529, 35);
            this.txt_logradouro.TabIndex = 110;
            // 
            // txt_bairro
            // 
            this.txt_bairro.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_bairro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_bairro.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_bairro.ForeColor = System.Drawing.Color.White;
            this.txt_bairro.Location = new System.Drawing.Point(39, 166);
            this.txt_bairro.Margin = new System.Windows.Forms.Padding(4);
            this.txt_bairro.MaxLength = 9999;
            this.txt_bairro.Multiline = true;
            this.txt_bairro.Name = "txt_bairro";
            this.txt_bairro.Size = new System.Drawing.Size(271, 35);
            this.txt_bairro.TabIndex = 109;
            // 
            // txt_cep
            // 
            this.txt_cep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_cep.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cep.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_cep.ForeColor = System.Drawing.Color.White;
            this.txt_cep.Location = new System.Drawing.Point(653, 166);
            this.txt_cep.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cep.MaxLength = 8;
            this.txt_cep.Multiline = true;
            this.txt_cep.Name = "txt_cep";
            this.txt_cep.Size = new System.Drawing.Size(222, 35);
            this.txt_cep.TabIndex = 108;
            this.txt_cep.Leave += new System.EventHandler(this.txt_cep_Leave);
            // 
            // txt_compl
            // 
            this.txt_compl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_compl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_compl.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_compl.ForeColor = System.Drawing.Color.White;
            this.txt_compl.Location = new System.Drawing.Point(39, 233);
            this.txt_compl.Margin = new System.Windows.Forms.Padding(4);
            this.txt_compl.MaxLength = 9999;
            this.txt_compl.Multiline = true;
            this.txt_compl.Name = "txt_compl";
            this.txt_compl.Size = new System.Drawing.Size(582, 35);
            this.txt_compl.TabIndex = 107;
            // 
            // txt_uf
            // 
            this.txt_uf.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_uf.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_uf.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_uf.ForeColor = System.Drawing.Color.White;
            this.txt_uf.Location = new System.Drawing.Point(777, 233);
            this.txt_uf.Margin = new System.Windows.Forms.Padding(4);
            this.txt_uf.MaxLength = 2;
            this.txt_uf.Multiline = true;
            this.txt_uf.Name = "txt_uf";
            this.txt_uf.Size = new System.Drawing.Size(98, 35);
            this.txt_uf.TabIndex = 106;
            // 
            // txt_cidade
            // 
            this.txt_cidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_cidade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cidade.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_cidade.ForeColor = System.Drawing.Color.White;
            this.txt_cidade.Location = new System.Drawing.Point(349, 166);
            this.txt_cidade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cidade.MaxLength = 9999;
            this.txt_cidade.Multiline = true;
            this.txt_cidade.Name = "txt_cidade";
            this.txt_cidade.Size = new System.Drawing.Size(271, 35);
            this.txt_cidade.TabIndex = 105;
            // 
            // txt_num
            // 
            this.txt_num.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_num.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_num.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_num.ForeColor = System.Drawing.Color.White;
            this.txt_num.Location = new System.Drawing.Point(653, 233);
            this.txt_num.Margin = new System.Windows.Forms.Padding(4);
            this.txt_num.MaxLength = 9999;
            this.txt_num.Multiline = true;
            this.txt_num.Name = "txt_num";
            this.txt_num.Size = new System.Drawing.Size(98, 35);
            this.txt_num.TabIndex = 104;
            // 
            // pc_passoDois3
            // 
            this.pc_passoDois3.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_dois;
            this.pc_passoDois3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pc_passoDois3.Location = new System.Drawing.Point(772, 11);
            this.pc_passoDois3.Margin = new System.Windows.Forms.Padding(4);
            this.pc_passoDois3.Name = "pc_passoDois3";
            this.pc_passoDois3.Size = new System.Drawing.Size(48, 44);
            this.pc_passoDois3.TabIndex = 95;
            this.pc_passoDois3.TabStop = false;
            // 
            // pc_passoTres3
            // 
            this.pc_passoTres3.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_tresSelect;
            this.pc_passoTres3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pc_passoTres3.Location = new System.Drawing.Point(825, 9);
            this.pc_passoTres3.Margin = new System.Windows.Forms.Padding(4);
            this.pc_passoTres3.Name = "pc_passoTres3";
            this.pc_passoTres3.Size = new System.Drawing.Size(53, 49);
            this.pc_passoTres3.TabIndex = 19;
            this.pc_passoTres3.TabStop = false;
            // 
            // btn_anteriorDois
            // 
            this.btn_anteriorDois.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_ant;
            this.btn_anteriorDois.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_anteriorDois.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_anteriorDois.Location = new System.Drawing.Point(39, 278);
            this.btn_anteriorDois.Margin = new System.Windows.Forms.Padding(4);
            this.btn_anteriorDois.Name = "btn_anteriorDois";
            this.btn_anteriorDois.Size = new System.Drawing.Size(143, 62);
            this.btn_anteriorDois.TabIndex = 16;
            this.btn_anteriorDois.TabStop = false;
            this.btn_anteriorDois.Click += new System.EventHandler(this.btn_anteriorDois_Click);
            // 
            // pc_passoUm3
            // 
            this.pc_passoUm3.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_um;
            this.pc_passoUm3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pc_passoUm3.Location = new System.Drawing.Point(716, 11);
            this.pc_passoUm3.Margin = new System.Windows.Forms.Padding(4);
            this.pc_passoUm3.Name = "pc_passoUm3";
            this.pc_passoUm3.Size = new System.Drawing.Size(48, 44);
            this.pc_passoUm3.TabIndex = 16;
            this.pc_passoUm3.TabStop = false;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(27, 63);
            this.panel7.Margin = new System.Windows.Forms.Padding(4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(867, 2);
            this.panel7.TabIndex = 22;
            // 
            // lbl_pedidoTres
            // 
            this.lbl_pedidoTres.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoTres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_pedidoTres.FlatAppearance.BorderSize = 0;
            this.lbl_pedidoTres.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoTres.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedidoTres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_pedidoTres.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedidoTres.ForeColor = System.Drawing.Color.White;
            this.lbl_pedidoTres.Location = new System.Drawing.Point(20, 16);
            this.lbl_pedidoTres.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_pedidoTres.Name = "lbl_pedidoTres";
            this.lbl_pedidoTres.Size = new System.Drawing.Size(313, 47);
            this.lbl_pedidoTres.TabIndex = 23;
            this.lbl_pedidoTres.Text = "Pedido";
            this.lbl_pedidoTres.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_pedidoTres.UseVisualStyleBackColor = false;
            // 
            // panel_enderecoV
            // 
            this.panel_enderecoV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_enderecoV.Controls.Add(this.lbl_complV);
            this.panel_enderecoV.Controls.Add(this.lbl_ufV);
            this.panel_enderecoV.Controls.Add(this.lbl_cidadeV);
            this.panel_enderecoV.Controls.Add(this.lbl_cepV);
            this.panel_enderecoV.Controls.Add(this.lbl_numV);
            this.panel_enderecoV.Controls.Add(this.lbl_bairroV);
            this.panel_enderecoV.Controls.Add(this.lbl_log);
            this.panel_enderecoV.Controls.Add(this.txt_logradouroV);
            this.panel_enderecoV.Controls.Add(this.txt_bairroV);
            this.panel_enderecoV.Controls.Add(this.txt_cepV);
            this.panel_enderecoV.Controls.Add(this.txt_complV);
            this.panel_enderecoV.Controls.Add(this.txt_ufV);
            this.panel_enderecoV.Controls.Add(this.txt_cidadeV);
            this.panel_enderecoV.Controls.Add(this.txt_numV);
            this.panel_enderecoV.Controls.Add(this.panel3);
            this.panel_enderecoV.Location = new System.Drawing.Point(101, 574);
            this.panel_enderecoV.Margin = new System.Windows.Forms.Padding(4);
            this.panel_enderecoV.Name = "panel_enderecoV";
            this.panel_enderecoV.Size = new System.Drawing.Size(1119, 197);
            this.panel_enderecoV.TabIndex = 23;
            this.panel_enderecoV.Visible = false;
            // 
            // lbl_complV
            // 
            this.lbl_complV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_complV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_complV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_complV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_complV.ForeColor = System.Drawing.Color.White;
            this.lbl_complV.Location = new System.Drawing.Point(603, 95);
            this.lbl_complV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_complV.Name = "lbl_complV";
            this.lbl_complV.Size = new System.Drawing.Size(283, 28);
            this.lbl_complV.TabIndex = 117;
            this.lbl_complV.Text = "Complemento:";
            this.lbl_complV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_ufV
            // 
            this.lbl_ufV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_ufV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_ufV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_ufV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_ufV.ForeColor = System.Drawing.Color.White;
            this.lbl_ufV.Location = new System.Drawing.Point(987, 20);
            this.lbl_ufV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_ufV.Name = "lbl_ufV";
            this.lbl_ufV.Size = new System.Drawing.Size(95, 28);
            this.lbl_ufV.TabIndex = 116;
            this.lbl_ufV.Text = "UF:";
            this.lbl_ufV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_cidadeV
            // 
            this.lbl_cidadeV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cidadeV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_cidadeV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_cidadeV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_cidadeV.ForeColor = System.Drawing.Color.White;
            this.lbl_cidadeV.Location = new System.Drawing.Point(336, 95);
            this.lbl_cidadeV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cidadeV.Name = "lbl_cidadeV";
            this.lbl_cidadeV.Size = new System.Drawing.Size(143, 28);
            this.lbl_cidadeV.TabIndex = 115;
            this.lbl_cidadeV.Text = "Cidade:";
            this.lbl_cidadeV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_cepV
            // 
            this.lbl_cepV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_cepV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_cepV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_cepV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_cepV.ForeColor = System.Drawing.Color.White;
            this.lbl_cepV.Location = new System.Drawing.Point(610, 20);
            this.lbl_cepV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_cepV.Name = "lbl_cepV";
            this.lbl_cepV.Size = new System.Drawing.Size(221, 28);
            this.lbl_cepV.TabIndex = 114;
            this.lbl_cepV.Text = "CEP:";
            this.lbl_cepV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_numV
            // 
            this.lbl_numV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_numV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_numV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_numV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_numV.ForeColor = System.Drawing.Color.White;
            this.lbl_numV.Location = new System.Drawing.Point(864, 20);
            this.lbl_numV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_numV.Name = "lbl_numV";
            this.lbl_numV.Size = new System.Drawing.Size(95, 28);
            this.lbl_numV.TabIndex = 113;
            this.lbl_numV.Text = "Número:";
            this.lbl_numV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_bairroV
            // 
            this.lbl_bairroV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_bairroV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_bairroV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_bairroV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_bairroV.ForeColor = System.Drawing.Color.White;
            this.lbl_bairroV.Location = new System.Drawing.Point(45, 95);
            this.lbl_bairroV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_bairroV.Name = "lbl_bairroV";
            this.lbl_bairroV.Size = new System.Drawing.Size(221, 28);
            this.lbl_bairroV.TabIndex = 112;
            this.lbl_bairroV.Text = "Bairro:";
            this.lbl_bairroV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_log
            // 
            this.lbl_log.BackColor = System.Drawing.Color.Transparent;
            this.lbl_log.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_log.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_log.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_log.ForeColor = System.Drawing.Color.White;
            this.lbl_log.Location = new System.Drawing.Point(51, 8);
            this.lbl_log.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_log.Name = "lbl_log";
            this.lbl_log.Size = new System.Drawing.Size(473, 28);
            this.lbl_log.TabIndex = 111;
            this.lbl_log.Text = "Logradouro:";
            this.lbl_log.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_logradouroV
            // 
            this.txt_logradouroV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_logradouroV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_logradouroV.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_logradouroV.ForeColor = System.Drawing.Color.White;
            this.txt_logradouroV.Location = new System.Drawing.Point(49, 52);
            this.txt_logradouroV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_logradouroV.MaxLength = 9999;
            this.txt_logradouroV.Multiline = true;
            this.txt_logradouroV.Name = "txt_logradouroV";
            this.txt_logradouroV.ReadOnly = true;
            this.txt_logradouroV.Size = new System.Drawing.Size(529, 35);
            this.txt_logradouroV.TabIndex = 110;
            // 
            // txt_bairroV
            // 
            this.txt_bairroV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_bairroV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_bairroV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_bairroV.ForeColor = System.Drawing.Color.White;
            this.txt_bairroV.Location = new System.Drawing.Point(48, 127);
            this.txt_bairroV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_bairroV.MaxLength = 9999;
            this.txt_bairroV.Multiline = true;
            this.txt_bairroV.Name = "txt_bairroV";
            this.txt_bairroV.ReadOnly = true;
            this.txt_bairroV.Size = new System.Drawing.Size(265, 35);
            this.txt_bairroV.TabIndex = 109;
            // 
            // txt_cepV
            // 
            this.txt_cepV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_cepV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cepV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_cepV.ForeColor = System.Drawing.Color.White;
            this.txt_cepV.Location = new System.Drawing.Point(609, 52);
            this.txt_cepV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cepV.MaxLength = 8;
            this.txt_cepV.Multiline = true;
            this.txt_cepV.Name = "txt_cepV";
            this.txt_cepV.ReadOnly = true;
            this.txt_cepV.Size = new System.Drawing.Size(222, 35);
            this.txt_cepV.TabIndex = 108;
            // 
            // txt_complV
            // 
            this.txt_complV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_complV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_complV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_complV.ForeColor = System.Drawing.Color.White;
            this.txt_complV.Location = new System.Drawing.Point(608, 127);
            this.txt_complV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_complV.MaxLength = 9999;
            this.txt_complV.Multiline = true;
            this.txt_complV.Name = "txt_complV";
            this.txt_complV.ReadOnly = true;
            this.txt_complV.Size = new System.Drawing.Size(482, 35);
            this.txt_complV.TabIndex = 107;
            // 
            // txt_ufV
            // 
            this.txt_ufV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_ufV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ufV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_ufV.ForeColor = System.Drawing.Color.White;
            this.txt_ufV.Location = new System.Drawing.Point(992, 52);
            this.txt_ufV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_ufV.MaxLength = 2;
            this.txt_ufV.Multiline = true;
            this.txt_ufV.Name = "txt_ufV";
            this.txt_ufV.ReadOnly = true;
            this.txt_ufV.Size = new System.Drawing.Size(98, 35);
            this.txt_ufV.TabIndex = 106;
            // 
            // txt_cidadeV
            // 
            this.txt_cidadeV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_cidadeV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_cidadeV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_cidadeV.ForeColor = System.Drawing.Color.White;
            this.txt_cidadeV.Location = new System.Drawing.Point(341, 127);
            this.txt_cidadeV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_cidadeV.MaxLength = 9999;
            this.txt_cidadeV.Multiline = true;
            this.txt_cidadeV.Name = "txt_cidadeV";
            this.txt_cidadeV.ReadOnly = true;
            this.txt_cidadeV.Size = new System.Drawing.Size(237, 35);
            this.txt_cidadeV.TabIndex = 105;
            // 
            // txt_numV
            // 
            this.txt_numV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_numV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_numV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_numV.ForeColor = System.Drawing.Color.White;
            this.txt_numV.Location = new System.Drawing.Point(864, 52);
            this.txt_numV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_numV.MaxLength = 9999;
            this.txt_numV.Multiline = true;
            this.txt_numV.Name = "txt_numV";
            this.txt_numV.ReadOnly = true;
            this.txt_numV.Size = new System.Drawing.Size(98, 35);
            this.txt_numV.TabIndex = 104;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(16, 2);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1107, 2);
            this.panel3.TabIndex = 22;
            // 
            // panel_pedido
            // 
            this.panel_pedido.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_pedido.Controls.Add(this.panel_produto);
            this.panel_pedido.Controls.Add(this.panel_cliente);
            this.panel_pedido.Controls.Add(this.panel8);
            this.panel_pedido.Controls.Add(this.label8);
            this.panel_pedido.Controls.Add(this.txt_valorTotalV);
            this.panel_pedido.Controls.Add(this.textBox9);
            this.panel_pedido.Controls.Add(this.btn_anteriorTres);
            this.panel_pedido.Controls.Add(this.btn_cadastrar);
            this.panel_pedido.Controls.Add(this.txt_clienteV);
            this.panel_pedido.Controls.Add(this.db_produtosV);
            this.panel_pedido.Controls.Add(this.panel1);
            this.panel_pedido.Controls.Add(this.lbl_produtoV);
            this.panel_pedido.Controls.Add(this.cb_tipoPedidoV);
            this.panel_pedido.Controls.Add(this.lbl_tipoPedidoV);
            this.panel_pedido.Controls.Add(this.cb_tipoPagV);
            this.panel_pedido.Controls.Add(this.txt_horaEntregaV);
            this.panel_pedido.Controls.Add(this.txt_dataPagV);
            this.panel_pedido.Controls.Add(this.txt_dataEntregaV);
            this.panel_pedido.Controls.Add(this.lbl_dataPagV);
            this.panel_pedido.Controls.Add(this.lbl_tipoPagV);
            this.panel_pedido.Controls.Add(this.lbl_horaEntregaV);
            this.panel_pedido.Controls.Add(this.lbl_dataEntregaV);
            this.panel_pedido.Controls.Add(this.cb_situacaoV);
            this.panel_pedido.Controls.Add(this.lbl_situacaoV);
            this.panel_pedido.Controls.Add(this.lbl_clienteV);
            this.panel_pedido.Controls.Add(this.lbl_tituloV);
            this.panel_pedido.Location = new System.Drawing.Point(98, 134);
            this.panel_pedido.Margin = new System.Windows.Forms.Padding(4);
            this.panel_pedido.Name = "panel_pedido";
            this.panel_pedido.Size = new System.Drawing.Size(1119, 421);
            this.panel_pedido.TabIndex = 24;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(19, 73);
            this.panel8.Margin = new System.Windows.Forms.Padding(4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(1107, 2);
            this.panel8.TabIndex = 98;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(899, 345);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 28);
            this.label8.TabIndex = 97;
            this.label8.Text = "R$";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txt_valorTotalV
            // 
            this.txt_valorTotalV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_valorTotalV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_valorTotalV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_valorTotalV.ForeColor = System.Drawing.Color.White;
            this.txt_valorTotalV.Location = new System.Drawing.Point(975, 347);
            this.txt_valorTotalV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_valorTotalV.MaxLength = 9999;
            this.txt_valorTotalV.Multiline = true;
            this.txt_valorTotalV.Name = "txt_valorTotalV";
            this.txt_valorTotalV.ReadOnly = true;
            this.txt_valorTotalV.Size = new System.Drawing.Size(109, 28);
            this.txt_valorTotalV.TabIndex = 96;
            this.txt_valorTotalV.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.Enabled = false;
            this.textBox9.ForeColor = System.Drawing.Color.White;
            this.textBox9.Location = new System.Drawing.Point(897, 318);
            this.textBox9.Margin = new System.Windows.Forms.Padding(4);
            this.textBox9.MaxLength = 9;
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(190, 86);
            this.textBox9.TabIndex = 95;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btn_anteriorTres
            // 
            this.btn_anteriorTres.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_ant;
            this.btn_anteriorTres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_anteriorTres.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_anteriorTres.Location = new System.Drawing.Point(803, 6);
            this.btn_anteriorTres.Margin = new System.Windows.Forms.Padding(4);
            this.btn_anteriorTres.Name = "btn_anteriorTres";
            this.btn_anteriorTres.Size = new System.Drawing.Size(143, 62);
            this.btn_anteriorTres.TabIndex = 94;
            this.btn_anteriorTres.TabStop = false;
            this.btn_anteriorTres.Click += new System.EventHandler(this.btn_anteriorTres_Click);
            // 
            // btn_cadastrar
            // 
            this.btn_cadastrar.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_fin;
            this.btn_cadastrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_cadastrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_cadastrar.Location = new System.Drawing.Point(953, 6);
            this.btn_cadastrar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_cadastrar.Name = "btn_cadastrar";
            this.btn_cadastrar.Size = new System.Drawing.Size(143, 62);
            this.btn_cadastrar.TabIndex = 93;
            this.btn_cadastrar.TabStop = false;
            this.btn_cadastrar.Click += new System.EventHandler(this.btn_cadastrar_Click);
            // 
            // txt_clienteV
            // 
            this.txt_clienteV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_clienteV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_clienteV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_clienteV.ForeColor = System.Drawing.Color.White;
            this.txt_clienteV.Location = new System.Drawing.Point(135, 85);
            this.txt_clienteV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_clienteV.MaxLength = 9999;
            this.txt_clienteV.Multiline = true;
            this.txt_clienteV.Name = "txt_clienteV";
            this.txt_clienteV.ReadOnly = true;
            this.txt_clienteV.Size = new System.Drawing.Size(722, 35);
            this.txt_clienteV.TabIndex = 92;
            // 
            // db_produtosV
            // 
            this.db_produtosV.AllowUserToAddRows = false;
            this.db_produtosV.AllowUserToDeleteRows = false;
            this.db_produtosV.AllowUserToResizeRows = false;
            dataGridViewCellStyle26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtosV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle26;
            this.db_produtosV.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.db_produtosV.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(215)))), ((int)(((byte)(214)))));
            this.db_produtosV.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.db_produtosV.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.db_produtosV.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle27.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtosV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle27;
            this.db_produtosV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.db_produtosV.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle28.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.db_produtosV.DefaultCellStyle = dataGridViewCellStyle28;
            this.db_produtosV.EnableHeadersVisualStyles = false;
            this.db_produtosV.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.db_produtosV.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.db_produtosV.Location = new System.Drawing.Point(48, 230);
            this.db_produtosV.Margin = new System.Windows.Forms.Padding(4);
            this.db_produtosV.Name = "db_produtosV";
            this.db_produtosV.ReadOnly = true;
            this.db_produtosV.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtosV.RowHeadersDefaultCellStyle = dataGridViewCellStyle29;
            this.db_produtosV.RowHeadersWidth = 51;
            this.db_produtosV.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtosV.RowsDefaultCellStyle = dataGridViewCellStyle30;
            this.db_produtosV.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.db_produtosV.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.db_produtosV.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.db_produtosV.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            this.db_produtosV.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtosV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.db_produtosV.Size = new System.Drawing.Size(595, 174);
            this.db_produtosV.TabIndex = 91;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(877, 91);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(3, 308);
            this.panel1.TabIndex = 90;
            // 
            // lbl_produtoV
            // 
            this.lbl_produtoV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_produtoV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_produtoV.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_produtoV.ForeColor = System.Drawing.Color.White;
            this.lbl_produtoV.Location = new System.Drawing.Point(43, 191);
            this.lbl_produtoV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_produtoV.Name = "lbl_produtoV";
            this.lbl_produtoV.Size = new System.Drawing.Size(143, 28);
            this.lbl_produtoV.TabIndex = 89;
            this.lbl_produtoV.Text = "Produtos:";
            this.lbl_produtoV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_tipoPedidoV
            // 
            this.cb_tipoPedidoV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_tipoPedidoV.Enabled = false;
            this.cb_tipoPedidoV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_tipoPedidoV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_tipoPedidoV.ForeColor = System.Drawing.Color.White;
            this.cb_tipoPedidoV.FormattingEnabled = true;
            this.cb_tipoPedidoV.Items.AddRange(new object[] {
            "Entrega",
            "Retirada"});
            this.cb_tipoPedidoV.Location = new System.Drawing.Point(215, 139);
            this.cb_tipoPedidoV.Margin = new System.Windows.Forms.Padding(4);
            this.cb_tipoPedidoV.Name = "cb_tipoPedidoV";
            this.cb_tipoPedidoV.Size = new System.Drawing.Size(225, 36);
            this.cb_tipoPedidoV.TabIndex = 88;
            // 
            // lbl_tipoPedidoV
            // 
            this.lbl_tipoPedidoV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_tipoPedidoV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_tipoPedidoV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_tipoPedidoV.ForeColor = System.Drawing.Color.White;
            this.lbl_tipoPedidoV.Location = new System.Drawing.Point(47, 143);
            this.lbl_tipoPedidoV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_tipoPedidoV.Name = "lbl_tipoPedidoV";
            this.lbl_tipoPedidoV.Size = new System.Drawing.Size(192, 28);
            this.lbl_tipoPedidoV.TabIndex = 87;
            this.lbl_tipoPedidoV.Text = "*Tipo de Pedido:";
            this.lbl_tipoPedidoV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_tipoPagV
            // 
            this.cb_tipoPagV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_tipoPagV.Enabled = false;
            this.cb_tipoPagV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_tipoPagV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_tipoPagV.ForeColor = System.Drawing.Color.White;
            this.cb_tipoPagV.FormattingEnabled = true;
            this.cb_tipoPagV.Items.AddRange(new object[] {
            "Dinheiro",
            "Cartão"});
            this.cb_tipoPagV.Location = new System.Drawing.Point(659, 139);
            this.cb_tipoPagV.Margin = new System.Windows.Forms.Padding(4);
            this.cb_tipoPagV.Name = "cb_tipoPagV";
            this.cb_tipoPagV.Size = new System.Drawing.Size(197, 36);
            this.cb_tipoPagV.TabIndex = 85;
            // 
            // txt_horaEntregaV
            // 
            this.txt_horaEntregaV.CalendarFont = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_horaEntregaV.CalendarForeColor = System.Drawing.Color.White;
            this.txt_horaEntregaV.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_horaEntregaV.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_horaEntregaV.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_horaEntregaV.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_horaEntregaV.Enabled = false;
            this.txt_horaEntregaV.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_horaEntregaV.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.txt_horaEntregaV.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.txt_horaEntregaV.Location = new System.Drawing.Point(659, 290);
            this.txt_horaEntregaV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_horaEntregaV.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_horaEntregaV.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_horaEntregaV.Name = "txt_horaEntregaV";
            this.txt_horaEntregaV.ShowUpDown = true;
            this.txt_horaEntregaV.Size = new System.Drawing.Size(197, 30);
            this.txt_horaEntregaV.TabIndex = 84;
            this.txt_horaEntregaV.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // txt_dataPagV
            // 
            this.txt_dataPagV.CalendarFont = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataPagV.CalendarForeColor = System.Drawing.Color.White;
            this.txt_dataPagV.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_dataPagV.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_dataPagV.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_dataPagV.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_dataPagV.Enabled = false;
            this.txt_dataPagV.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataPagV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_dataPagV.Location = new System.Drawing.Point(661, 363);
            this.txt_dataPagV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_dataPagV.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_dataPagV.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_dataPagV.Name = "txt_dataPagV";
            this.txt_dataPagV.Size = new System.Drawing.Size(195, 30);
            this.txt_dataPagV.TabIndex = 83;
            this.txt_dataPagV.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // txt_dataEntregaV
            // 
            this.txt_dataEntregaV.CalendarFont = new System.Drawing.Font("Segoe UI", 11.25F);
            this.txt_dataEntregaV.CalendarForeColor = System.Drawing.Color.White;
            this.txt_dataEntregaV.CalendarMonthBackground = System.Drawing.Color.WhiteSmoke;
            this.txt_dataEntregaV.CalendarTitleBackColor = System.Drawing.Color.Transparent;
            this.txt_dataEntregaV.CalendarTitleForeColor = System.Drawing.Color.Black;
            this.txt_dataEntregaV.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_dataEntregaV.Enabled = false;
            this.txt_dataEntregaV.Font = new System.Drawing.Font("Segoe UI", 10.25F);
            this.txt_dataEntregaV.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_dataEntregaV.Location = new System.Drawing.Point(659, 224);
            this.txt_dataEntregaV.Margin = new System.Windows.Forms.Padding(4);
            this.txt_dataEntregaV.MaxDate = new System.DateTime(2040, 12, 31, 0, 0, 0, 0);
            this.txt_dataEntregaV.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.txt_dataEntregaV.Name = "txt_dataEntregaV";
            this.txt_dataEntregaV.Size = new System.Drawing.Size(197, 30);
            this.txt_dataEntregaV.TabIndex = 82;
            this.txt_dataEntregaV.Value = new System.DateTime(2020, 10, 20, 0, 0, 0, 0);
            // 
            // lbl_dataPagV
            // 
            this.lbl_dataPagV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_dataPagV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_dataPagV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_dataPagV.ForeColor = System.Drawing.Color.White;
            this.lbl_dataPagV.Location = new System.Drawing.Point(656, 331);
            this.lbl_dataPagV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dataPagV.Name = "lbl_dataPagV";
            this.lbl_dataPagV.Size = new System.Drawing.Size(204, 28);
            this.lbl_dataPagV.TabIndex = 81;
            this.lbl_dataPagV.Text = "*Data de Pagamento:";
            this.lbl_dataPagV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_tipoPagV
            // 
            this.lbl_tipoPagV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_tipoPagV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_tipoPagV.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tipoPagV.ForeColor = System.Drawing.Color.White;
            this.lbl_tipoPagV.Location = new System.Drawing.Point(451, 142);
            this.lbl_tipoPagV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_tipoPagV.Name = "lbl_tipoPagV";
            this.lbl_tipoPagV.Size = new System.Drawing.Size(204, 28);
            this.lbl_tipoPagV.TabIndex = 80;
            this.lbl_tipoPagV.Text = "*Tipo de Pagamento:";
            this.lbl_tipoPagV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_horaEntregaV
            // 
            this.lbl_horaEntregaV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_horaEntregaV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_horaEntregaV.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_horaEntregaV.ForeColor = System.Drawing.Color.White;
            this.lbl_horaEntregaV.Location = new System.Drawing.Point(656, 260);
            this.lbl_horaEntregaV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_horaEntregaV.Name = "lbl_horaEntregaV";
            this.lbl_horaEntregaV.Size = new System.Drawing.Size(193, 28);
            this.lbl_horaEntregaV.TabIndex = 79;
            this.lbl_horaEntregaV.Text = "*Hora de Entrega:";
            this.lbl_horaEntregaV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_dataEntregaV
            // 
            this.lbl_dataEntregaV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_dataEntregaV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_dataEntregaV.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dataEntregaV.ForeColor = System.Drawing.Color.White;
            this.lbl_dataEntregaV.Location = new System.Drawing.Point(656, 193);
            this.lbl_dataEntregaV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_dataEntregaV.Name = "lbl_dataEntregaV";
            this.lbl_dataEntregaV.Size = new System.Drawing.Size(193, 28);
            this.lbl_dataEntregaV.TabIndex = 78;
            this.lbl_dataEntregaV.Text = "*Data de Entrega:";
            this.lbl_dataEntregaV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // cb_situacaoV
            // 
            this.cb_situacaoV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_situacaoV.Enabled = false;
            this.cb_situacaoV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_situacaoV.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_situacaoV.ForeColor = System.Drawing.Color.White;
            this.cb_situacaoV.FormattingEnabled = true;
            this.cb_situacaoV.Items.AddRange(new object[] {
            "Pendente",
            "Em Andamento"});
            this.cb_situacaoV.Location = new System.Drawing.Point(897, 135);
            this.cb_situacaoV.Margin = new System.Windows.Forms.Padding(4);
            this.cb_situacaoV.Name = "cb_situacaoV";
            this.cb_situacaoV.Size = new System.Drawing.Size(195, 36);
            this.cb_situacaoV.TabIndex = 46;
            // 
            // lbl_situacaoV
            // 
            this.lbl_situacaoV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_situacaoV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_situacaoV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_situacaoV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_situacaoV.ForeColor = System.Drawing.Color.White;
            this.lbl_situacaoV.Location = new System.Drawing.Point(893, 103);
            this.lbl_situacaoV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_situacaoV.Name = "lbl_situacaoV";
            this.lbl_situacaoV.Size = new System.Drawing.Size(95, 28);
            this.lbl_situacaoV.TabIndex = 45;
            this.lbl_situacaoV.Text = "Situação:";
            this.lbl_situacaoV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_clienteV
            // 
            this.lbl_clienteV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_clienteV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_clienteV.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_clienteV.ForeColor = System.Drawing.Color.White;
            this.lbl_clienteV.Location = new System.Drawing.Point(47, 86);
            this.lbl_clienteV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_clienteV.Name = "lbl_clienteV";
            this.lbl_clienteV.Size = new System.Drawing.Size(87, 28);
            this.lbl_clienteV.TabIndex = 42;
            this.lbl_clienteV.Text = "*Cliente:";
            this.lbl_clienteV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // lbl_tituloV
            // 
            this.lbl_tituloV.BackColor = System.Drawing.Color.Transparent;
            this.lbl_tituloV.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_tituloV.FlatAppearance.BorderSize = 0;
            this.lbl_tituloV.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_tituloV.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_tituloV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_tituloV.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tituloV.ForeColor = System.Drawing.Color.White;
            this.lbl_tituloV.Location = new System.Drawing.Point(5, 23);
            this.lbl_tituloV.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_tituloV.Name = "lbl_tituloV";
            this.lbl_tituloV.Size = new System.Drawing.Size(405, 47);
            this.lbl_tituloV.TabIndex = 23;
            this.lbl_tituloV.TabStop = false;
            this.lbl_tituloV.Text = "Confirmar Pedido";
            this.lbl_tituloV.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_tituloV.UseVisualStyleBackColor = false;
            // 
            // panel_produto
            // 
            this.panel_produto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_produto.Controls.Add(this.button1);
            this.panel_produto.Controls.Add(this.lbl_pedido);
            this.panel_produto.Controls.Add(this.btn_addProd);
            this.panel_produto.Controls.Add(this.btn_limpar);
            this.panel_produto.Controls.Add(this.pic_passoUm);
            this.panel_produto.Controls.Add(this.pic_passoDois);
            this.panel_produto.Controls.Add(this.lbl_obs);
            this.panel_produto.Controls.Add(this.txt_obs);
            this.panel_produto.Controls.Add(this.lbl_qtd);
            this.panel_produto.Controls.Add(this.txt_quantidade);
            this.panel_produto.Controls.Add(this.cb_produtos);
            this.panel_produto.Controls.Add(this.lbl_produto);
            this.panel_produto.Controls.Add(this.txt_valorTotal);
            this.panel_produto.Controls.Add(this.lbl_valor);
            this.panel_produto.Controls.Add(this.label9);
            this.panel_produto.Controls.Add(this.textBox);
            this.panel_produto.Controls.Add(this.db_produtos);
            this.panel_produto.Controls.Add(this.panel_produtos);
            this.panel_produto.Controls.Add(this.panel4);
            this.panel_produto.Controls.Add(this.btn_proximo);
            this.panel_produto.Controls.Add(this.panel);
            this.panel_produto.Controls.Add(this.panel5);
            this.panel_produto.Controls.Add(this.pic_passoTres);
            this.panel_produto.Location = new System.Drawing.Point(142, 6);
            this.panel_produto.Margin = new System.Windows.Forms.Padding(4);
            this.panel_produto.Name = "panel_produto";
            this.panel_produto.Size = new System.Drawing.Size(986, 461);
            this.panel_produto.TabIndex = 99;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_add;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(37, 403);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(219, 38);
            this.button1.TabIndex = 99;
            this.button1.Text = "        Adicionar  novo Produto";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lbl_pedido
            // 
            this.lbl_pedido.BackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_pedido.FlatAppearance.BorderSize = 0;
            this.lbl_pedido.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.lbl_pedido.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_pedido.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedido.ForeColor = System.Drawing.Color.White;
            this.lbl_pedido.Location = new System.Drawing.Point(16, 8);
            this.lbl_pedido.Margin = new System.Windows.Forms.Padding(4);
            this.lbl_pedido.Name = "lbl_pedido";
            this.lbl_pedido.Size = new System.Drawing.Size(313, 47);
            this.lbl_pedido.TabIndex = 23;
            this.lbl_pedido.Text = "Pedido";
            this.lbl_pedido.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.lbl_pedido.UseVisualStyleBackColor = false;
            // 
            // btn_addProd
            // 
            this.btn_addProd.BackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_add;
            this.btn_addProd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_addProd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_addProd.FlatAppearance.BorderSize = 0;
            this.btn_addProd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_addProd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_addProd.Font = new System.Drawing.Font("Segoe UI", 9.75F);
            this.btn_addProd.ForeColor = System.Drawing.Color.White;
            this.btn_addProd.Location = new System.Drawing.Point(720, 284);
            this.btn_addProd.Margin = new System.Windows.Forms.Padding(4);
            this.btn_addProd.Name = "btn_addProd";
            this.btn_addProd.Size = new System.Drawing.Size(151, 38);
            this.btn_addProd.TabIndex = 98;
            this.btn_addProd.Text = "        Adicionar ";
            this.btn_addProd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_addProd.UseVisualStyleBackColor = false;
            this.btn_addProd.Visible = false;
            this.btn_addProd.Click += new System.EventHandler(this.btn_addProd_Click_1);
            // 
            // btn_limpar
            // 
            this.btn_limpar.BackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_limpar.FlatAppearance.BorderSize = 0;
            this.btn_limpar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_limpar.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpar.ForeColor = System.Drawing.Color.Black;
            this.btn_limpar.Image = global::SeitonSystem.Properties.Resources.icone_deletar;
            this.btn_limpar.Location = new System.Drawing.Point(647, 284);
            this.btn_limpar.Margin = new System.Windows.Forms.Padding(4);
            this.btn_limpar.Name = "btn_limpar";
            this.btn_limpar.Size = new System.Drawing.Size(43, 37);
            this.btn_limpar.TabIndex = 97;
            this.btn_limpar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_limpar.UseVisualStyleBackColor = false;
            this.btn_limpar.Visible = false;
            this.btn_limpar.Click += new System.EventHandler(this.btn_limpar_Click_1);
            // 
            // pic_passoUm
            // 
            this.pic_passoUm.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_umSelect;
            this.pic_passoUm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoUm.Location = new System.Drawing.Point(713, 7);
            this.pic_passoUm.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoUm.Name = "pic_passoUm";
            this.pic_passoUm.Size = new System.Drawing.Size(53, 49);
            this.pic_passoUm.TabIndex = 96;
            this.pic_passoUm.TabStop = false;
            // 
            // pic_passoDois
            // 
            this.pic_passoDois.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_dois;
            this.pic_passoDois.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoDois.Location = new System.Drawing.Point(773, 11);
            this.pic_passoDois.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoDois.Name = "pic_passoDois";
            this.pic_passoDois.Size = new System.Drawing.Size(48, 44);
            this.pic_passoDois.TabIndex = 95;
            this.pic_passoDois.TabStop = false;
            // 
            // lbl_obs
            // 
            this.lbl_obs.BackColor = System.Drawing.Color.Transparent;
            this.lbl_obs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_obs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_obs.Font = new System.Drawing.Font("Segoe UI", 11.25F);
            this.lbl_obs.ForeColor = System.Drawing.Color.White;
            this.lbl_obs.Location = new System.Drawing.Point(647, 146);
            this.lbl_obs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_obs.Name = "lbl_obs";
            this.lbl_obs.Size = new System.Drawing.Size(224, 30);
            this.lbl_obs.TabIndex = 94;
            this.lbl_obs.Text = "Observação:";
            this.lbl_obs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txt_obs
            // 
            this.txt_obs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_obs.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_obs.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.txt_obs.ForeColor = System.Drawing.Color.White;
            this.txt_obs.Location = new System.Drawing.Point(647, 177);
            this.txt_obs.Margin = new System.Windows.Forms.Padding(4);
            this.txt_obs.MaxLength = 9999;
            this.txt_obs.Multiline = true;
            this.txt_obs.Name = "txt_obs";
            this.txt_obs.ReadOnly = true;
            this.txt_obs.Size = new System.Drawing.Size(223, 100);
            this.txt_obs.TabIndex = 93;
            // 
            // lbl_qtd
            // 
            this.lbl_qtd.BackColor = System.Drawing.Color.Transparent;
            this.lbl_qtd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbl_qtd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_qtd.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_qtd.ForeColor = System.Drawing.Color.White;
            this.lbl_qtd.Location = new System.Drawing.Point(649, 87);
            this.lbl_qtd.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_qtd.Name = "lbl_qtd";
            this.lbl_qtd.Size = new System.Drawing.Size(139, 28);
            this.lbl_qtd.TabIndex = 89;
            this.lbl_qtd.Text = "*Quantidade:";
            this.lbl_qtd.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_quantidade
            // 
            this.txt_quantidade.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_quantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_quantidade.Font = new System.Drawing.Font("Segoe UI", 13.25F);
            this.txt_quantidade.ForeColor = System.Drawing.Color.White;
            this.txt_quantidade.Location = new System.Drawing.Point(801, 86);
            this.txt_quantidade.Margin = new System.Windows.Forms.Padding(4);
            this.txt_quantidade.Name = "txt_quantidade";
            this.txt_quantidade.ReadOnly = true;
            this.txt_quantidade.Size = new System.Drawing.Size(75, 33);
            this.txt_quantidade.TabIndex = 88;
            // 
            // cb_produtos
            // 
            this.cb_produtos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.cb_produtos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cb_produtos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cb_produtos.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.cb_produtos.ForeColor = System.Drawing.Color.DimGray;
            this.cb_produtos.FormattingEnabled = true;
            this.cb_produtos.Location = new System.Drawing.Point(143, 82);
            this.cb_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.cb_produtos.Name = "cb_produtos";
            this.cb_produtos.Size = new System.Drawing.Size(495, 36);
            this.cb_produtos.TabIndex = 87;
            this.cb_produtos.SelectedIndexChanged += new System.EventHandler(this.cb_produtos_SelectedIndexChanged_1);
            // 
            // lbl_produto
            // 
            this.lbl_produto.BackColor = System.Drawing.Color.Transparent;
            this.lbl_produto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_produto.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_produto.ForeColor = System.Drawing.Color.White;
            this.lbl_produto.Location = new System.Drawing.Point(32, 86);
            this.lbl_produto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_produto.Name = "lbl_produto";
            this.lbl_produto.Size = new System.Drawing.Size(113, 28);
            this.lbl_produto.TabIndex = 86;
            this.lbl_produto.Text = "Produtos:";
            this.lbl_produto.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // txt_valorTotal
            // 
            this.txt_valorTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.txt_valorTotal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_valorTotal.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.txt_valorTotal.ForeColor = System.Drawing.Color.White;
            this.txt_valorTotal.Location = new System.Drawing.Point(448, 348);
            this.txt_valorTotal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_valorTotal.MaxLength = 9;
            this.txt_valorTotal.Multiline = true;
            this.txt_valorTotal.Name = "txt_valorTotal";
            this.txt_valorTotal.ReadOnly = true;
            this.txt_valorTotal.Size = new System.Drawing.Size(152, 38);
            this.txt_valorTotal.TabIndex = 85;
            this.txt_valorTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_valorTotal.WordWrap = false;
            // 
            // lbl_valor
            // 
            this.lbl_valor.BackColor = System.Drawing.Color.Transparent;
            this.lbl_valor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_valor.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_valor.ForeColor = System.Drawing.Color.White;
            this.lbl_valor.Location = new System.Drawing.Point(217, 352);
            this.lbl_valor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_valor.Name = "lbl_valor";
            this.lbl_valor.Size = new System.Drawing.Size(147, 28);
            this.lbl_valor.TabIndex = 83;
            this.lbl_valor.Text = "Valor Total:";
            this.lbl_valor.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(372, 348);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 38);
            this.label9.TabIndex = 84;
            this.label9.Text = "R$";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox
            // 
            this.textBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(219)))), ((int)(((byte)(171)))), ((int)(((byte)(177)))));
            this.textBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox.ForeColor = System.Drawing.Color.White;
            this.textBox.Location = new System.Drawing.Point(371, 345);
            this.textBox.Margin = new System.Windows.Forms.Padding(4);
            this.textBox.MaxLength = 9;
            this.textBox.Multiline = true;
            this.textBox.Name = "textBox";
            this.textBox.ReadOnly = true;
            this.textBox.Size = new System.Drawing.Size(233, 45);
            this.textBox.TabIndex = 82;
            this.textBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // db_produtos
            // 
            this.db_produtos.AllowUserToAddRows = false;
            this.db_produtos.AllowUserToDeleteRows = false;
            this.db_produtos.AllowUserToResizeRows = false;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle21;
            this.db_produtos.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            this.db_produtos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(215)))), ((int)(((byte)(214)))));
            this.db_produtos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.db_produtos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.RaisedVertical;
            this.db_produtos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.Padding = new System.Windows.Forms.Padding(0, 2, 0, 0);
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.db_produtos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.db_produtos.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle23.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.db_produtos.DefaultCellStyle = dataGridViewCellStyle23;
            this.db_produtos.EnableHeadersVisualStyles = false;
            this.db_produtos.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.db_produtos.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.db_produtos.Location = new System.Drawing.Point(39, 137);
            this.db_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.db_produtos.Name = "db_produtos";
            this.db_produtos.ReadOnly = true;
            this.db_produtos.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.db_produtos.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.db_produtos.RowHeadersWidth = 51;
            this.db_produtos.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.RowsDefaultCellStyle = dataGridViewCellStyle25;
            this.db_produtos.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(207)))), ((int)(((byte)(206)))));
            this.db_produtos.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.db_produtos.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.db_produtos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(195)))), ((int)(((byte)(167)))), ((int)(((byte)(166)))));
            this.db_produtos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.db_produtos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.db_produtos.Size = new System.Drawing.Size(596, 178);
            this.db_produtos.TabIndex = 81;
            this.db_produtos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.db_produtos_CellContentClick_1);
            // 
            // panel_produtos
            // 
            this.panel_produtos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(218)))), ((int)(((byte)(167)))), ((int)(((byte)(177)))));
            this.panel_produtos.BackgroundImage = global::SeitonSystem.Properties.Resources.retangulo;
            this.panel_produtos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel_produtos.Controls.Add(this.btn_excluir);
            this.panel_produtos.Location = new System.Drawing.Point(16, 311);
            this.panel_produtos.Margin = new System.Windows.Forms.Padding(4);
            this.panel_produtos.Name = "panel_produtos";
            this.panel_produtos.Size = new System.Drawing.Size(152, 66);
            this.panel_produtos.TabIndex = 80;
            this.panel_produtos.Visible = false;
            // 
            // btn_excluir
            // 
            this.btn_excluir.BackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_excluir.FlatAppearance.BorderSize = 0;
            this.btn_excluir.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btn_excluir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_excluir.Font = new System.Drawing.Font("Segoe UI Semilight", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_excluir.ForeColor = System.Drawing.Color.Black;
            this.btn_excluir.Image = global::SeitonSystem.Properties.Resources.icone_deletar;
            this.btn_excluir.ImageAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.btn_excluir.Location = new System.Drawing.Point(17, 15);
            this.btn_excluir.Margin = new System.Windows.Forms.Padding(4);
            this.btn_excluir.Name = "btn_excluir";
            this.btn_excluir.Size = new System.Drawing.Size(121, 39);
            this.btn_excluir.TabIndex = 39;
            this.btn_excluir.Text = "Deletar";
            this.btn_excluir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_excluir.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_excluir.UseVisualStyleBackColor = false;
            this.btn_excluir.Click += new System.EventHandler(this.btn_excluir_Click_1);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(636, 140);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(3, 182);
            this.panel4.TabIndex = 79;
            // 
            // btn_proximo
            // 
            this.btn_proximo.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_prox;
            this.btn_proximo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btn_proximo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_proximo.Location = new System.Drawing.Point(735, 342);
            this.btn_proximo.Margin = new System.Windows.Forms.Padding(4);
            this.btn_proximo.Name = "btn_proximo";
            this.btn_proximo.Size = new System.Drawing.Size(143, 62);
            this.btn_proximo.TabIndex = 21;
            this.btn_proximo.TabStop = false;
            this.btn_proximo.Click += new System.EventHandler(this.btn_proximo_Click_1);
            // 
            // panel
            // 
            this.panel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(215)))), ((int)(((byte)(214)))));
            this.panel.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.panel.ForeColor = System.Drawing.Color.White;
            this.panel.Location = new System.Drawing.Point(631, 137);
            this.panel.Margin = new System.Windows.Forms.Padding(4);
            this.panel.MaxLength = 9;
            this.panel.Multiline = true;
            this.panel.Name = "panel";
            this.panel.ReadOnly = true;
            this.panel.Size = new System.Drawing.Size(245, 194);
            this.panel.TabIndex = 78;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.White;
            this.panel5.Location = new System.Drawing.Point(27, 63);
            this.panel5.Margin = new System.Windows.Forms.Padding(4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(867, 2);
            this.panel5.TabIndex = 22;
            // 
            // pic_passoTres
            // 
            this.pic_passoTres.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_tres;
            this.pic_passoTres.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_passoTres.Location = new System.Drawing.Point(828, 11);
            this.pic_passoTres.Margin = new System.Windows.Forms.Padding(4);
            this.pic_passoTres.Name = "pic_passoTres";
            this.pic_passoTres.Size = new System.Drawing.Size(48, 44);
            this.pic_passoTres.TabIndex = 18;
            this.pic_passoTres.TabStop = false;
            // 
            // btn_financas
            // 
            this.btn_financas.BackColor = System.Drawing.Color.White;
            this.btn_financas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_financas.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btn_financas.FlatAppearance.BorderSize = 0;
            this.btn_financas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btn_financas.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.Menu;
            this.btn_financas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_financas.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_financas.Location = new System.Drawing.Point(963, 0);
            this.btn_financas.Margin = new System.Windows.Forms.Padding(4);
            this.btn_financas.Name = "btn_financas";
            this.btn_financas.Size = new System.Drawing.Size(201, 38);
            this.btn_financas.TabIndex = 28;
            this.btn_financas.Text = "Finanças";
            this.btn_financas.UseVisualStyleBackColor = false;
            this.btn_financas.Click += new System.EventHandler(this.btn_financas_Click);
            // 
            // pic_cantoe
            // 
            this.pic_cantoe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(65)))), ((int)(((byte)(33)))));
            this.pic_cantoe.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_camE;
            this.pic_cantoe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_cantoe.Location = new System.Drawing.Point(51, 0);
            this.pic_cantoe.Margin = new System.Windows.Forms.Padding(4);
            this.pic_cantoe.Name = "pic_cantoe";
            this.pic_cantoe.Size = new System.Drawing.Size(111, 38);
            this.pic_cantoe.TabIndex = 31;
            this.pic_cantoe.TabStop = false;
            // 
            // pic_caldaE
            // 
            this.pic_caldaE.BackgroundImage = global::SeitonSystem.Properties.Resources.chocEscorrendoE;
            this.pic_caldaE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_caldaE.Location = new System.Drawing.Point(-3, -43);
            this.pic_caldaE.Margin = new System.Windows.Forms.Padding(4);
            this.pic_caldaE.Name = "pic_caldaE";
            this.pic_caldaE.Size = new System.Drawing.Size(164, 218);
            this.pic_caldaE.TabIndex = 30;
            this.pic_caldaE.TabStop = false;
            // 
            // pic_cantod
            // 
            this.pic_cantod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(103)))), ((int)(((byte)(65)))), ((int)(((byte)(33)))));
            this.pic_cantod.BackgroundImage = global::SeitonSystem.Properties.Resources.icon_camD;
            this.pic_cantod.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_cantod.Location = new System.Drawing.Point(1163, 0);
            this.pic_cantod.Margin = new System.Windows.Forms.Padding(4);
            this.pic_cantod.Name = "pic_cantod";
            this.pic_cantod.Size = new System.Drawing.Size(111, 38);
            this.pic_cantod.TabIndex = 29;
            this.pic_cantod.TabStop = false;
            // 
            // pic_caldaD
            // 
            this.pic_caldaD.BackgroundImage = global::SeitonSystem.Properties.Resources.chocEscorrendoD;
            this.pic_caldaD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_caldaD.Location = new System.Drawing.Point(1156, -43);
            this.pic_caldaD.Margin = new System.Windows.Forms.Padding(4);
            this.pic_caldaD.Name = "pic_caldaD";
            this.pic_caldaD.Size = new System.Drawing.Size(164, 218);
            this.pic_caldaD.TabIndex = 27;
            this.pic_caldaD.TabStop = false;
            // 
            // pic_logo
            // 
            this.pic_logo.BackgroundImage = global::SeitonSystem.Properties.Resources.logo2;
            this.pic_logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_logo.Location = new System.Drawing.Point(556, -4);
            this.pic_logo.Margin = new System.Windows.Forms.Padding(4);
            this.pic_logo.Name = "pic_logo";
            this.pic_logo.Size = new System.Drawing.Size(196, 190);
            this.pic_logo.TabIndex = 14;
            this.pic_logo.TabStop = false;
            // 
            // pic_calda
            // 
            this.pic_calda.BackColor = System.Drawing.Color.Transparent;
            this.pic_calda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pic_calda.BackgroundImage")));
            this.pic_calda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pic_calda.Location = new System.Drawing.Point(161, 38);
            this.pic_calda.Margin = new System.Windows.Forms.Padding(4);
            this.pic_calda.Name = "pic_calda";
            this.pic_calda.Size = new System.Drawing.Size(995, 151);
            this.pic_calda.TabIndex = 13;
            this.pic_calda.TabStop = false;
            // 
            // PedidoCadastrarView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(156)))), ((int)(((byte)(154)))));
            this.ClientSize = new System.Drawing.Size(1368, 902);
            this.Controls.Add(this.panel_pedido);
            this.Controls.Add(this.pic_cantoe);
            this.Controls.Add(this.pic_caldaE);
            this.Controls.Add(this.pic_cantod);
            this.Controls.Add(this.btn_financas);
            this.Controls.Add(this.pic_caldaD);
            this.Controls.Add(this.pic_logo);
            this.Controls.Add(this.pic_calda);
            this.Controls.Add(this.btn_pedido);
            this.Controls.Add(this.btn_produtos);
            this.Controls.Add(this.btn_clientes);
            this.Controls.Add(this.panel_enderecoV);
            this.Controls.Add(this.panel_endereco);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "PedidoCadastrarView";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seiton System";
            this.panel_cliente.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoDois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoDois2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anterior)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoDoisE)).EndInit();
            this.panel_endereco.ResumeLayout(false);
            this.panel_endereco.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximoTres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoDois3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoTres3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anteriorDois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pc_passoUm3)).EndInit();
            this.panel_enderecoV.ResumeLayout(false);
            this.panel_enderecoV.PerformLayout();
            this.panel_pedido.ResumeLayout(false);
            this.panel_pedido.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_anteriorTres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_cadastrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtosV)).EndInit();
            this.panel_produto.ResumeLayout(false);
            this.panel_produto.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoUm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoDois)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txt_quantidade)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.db_produtos)).EndInit();
            this.panel_produtos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_proximo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_passoTres)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cantoe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_caldaE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cantod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_caldaD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_calda)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pic_logo;
        private System.Windows.Forms.PictureBox pic_calda;
        private System.Windows.Forms.Button btn_pedido;
        private System.Windows.Forms.Button btn_produtos;
        private System.Windows.Forms.Button btn_clientes;
        private System.Windows.Forms.Panel panel_cliente;
        private System.Windows.Forms.PictureBox pic_passoTres4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button lbl_pedidoDois;
        private System.Windows.Forms.ComboBox cb_cliente;
        private System.Windows.Forms.Label lbl_cliente;
        private System.Windows.Forms.ComboBox cb_situacao;
        private System.Windows.Forms.Label lbl_situacao;
        private System.Windows.Forms.ComboBox cb_tipoPag;
        private System.Windows.Forms.DateTimePicker txt_horaEntrega;
        private System.Windows.Forms.DateTimePicker txt_dataPag;
        private System.Windows.Forms.DateTimePicker txt_dataEntrega;
        private System.Windows.Forms.Label lbl_dataPag;
        private System.Windows.Forms.Label lbl_tipo;
        private System.Windows.Forms.Label lbl_HoraEntrega;
        private System.Windows.Forms.Label lbl_dataEntrega;
        private System.Windows.Forms.Label lbl_tpPedido;
        private System.Windows.Forms.ComboBox cb_tipoPedido;
        private System.Windows.Forms.PictureBox btn_proximoDoisE;
        private System.Windows.Forms.Panel panel_endereco;
        private System.Windows.Forms.Button lbl_endereco;
        private System.Windows.Forms.Label lbl_compl;
        private System.Windows.Forms.Label lbl_uf;
        private System.Windows.Forms.Label lbl_cidade;
        private System.Windows.Forms.Label lbl_cep;
        private System.Windows.Forms.Label lbl_num;
        private System.Windows.Forms.Label lbl_bairro;
        private System.Windows.Forms.Label lbl_logradouro;
        private System.Windows.Forms.TextBox txt_logradouro;
        private System.Windows.Forms.TextBox txt_bairro;
        private System.Windows.Forms.TextBox txt_cep;
        private System.Windows.Forms.TextBox txt_compl;
        private System.Windows.Forms.TextBox txt_uf;
        private System.Windows.Forms.TextBox txt_cidade;
        private System.Windows.Forms.TextBox txt_num;
        private System.Windows.Forms.PictureBox pc_passoDois3;
        private System.Windows.Forms.PictureBox pc_passoTres3;
        private System.Windows.Forms.PictureBox btn_anteriorDois;
        private System.Windows.Forms.PictureBox pc_passoUm3;
        private System.Windows.Forms.Button lbl_pedidoTres;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pic_passoUm2;
        private System.Windows.Forms.PictureBox pc_passoDois2;
        private System.Windows.Forms.PictureBox btn_anterior;
        private System.Windows.Forms.Panel panel_enderecoV;
        private System.Windows.Forms.Label lbl_complV;
        private System.Windows.Forms.Label lbl_ufV;
        private System.Windows.Forms.Label lbl_cidadeV;
        private System.Windows.Forms.Label lbl_cepV;
        private System.Windows.Forms.Label lbl_numV;
        private System.Windows.Forms.Label lbl_bairroV;
        private System.Windows.Forms.Label lbl_log;
        private System.Windows.Forms.TextBox txt_logradouroV;
        private System.Windows.Forms.TextBox txt_bairroV;
        private System.Windows.Forms.TextBox txt_cepV;
        private System.Windows.Forms.TextBox txt_complV;
        private System.Windows.Forms.TextBox txt_ufV;
        private System.Windows.Forms.TextBox txt_cidadeV;
        private System.Windows.Forms.TextBox txt_numV;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel_pedido;
        private System.Windows.Forms.ComboBox cb_tipoPedidoV;
        private System.Windows.Forms.Label lbl_tipoPedidoV;
        private System.Windows.Forms.ComboBox cb_tipoPagV;
        private System.Windows.Forms.DateTimePicker txt_horaEntregaV;
        private System.Windows.Forms.DateTimePicker txt_dataPagV;
        private System.Windows.Forms.DateTimePicker txt_dataEntregaV;
        private System.Windows.Forms.Label lbl_dataPagV;
        private System.Windows.Forms.Label lbl_tipoPagV;
        private System.Windows.Forms.Label lbl_horaEntregaV;
        private System.Windows.Forms.Label lbl_dataEntregaV;
        private System.Windows.Forms.ComboBox cb_situacaoV;
        private System.Windows.Forms.Label lbl_situacaoV;
        private System.Windows.Forms.Label lbl_clienteV;
        private System.Windows.Forms.Button lbl_tituloV;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_produtoV;
        private MetroFramework.Controls.MetroGrid db_produtosV;
        private System.Windows.Forms.TextBox txt_clienteV;
        private System.Windows.Forms.PictureBox btn_proximoTres;
        private System.Windows.Forms.PictureBox btn_anteriorTres;
        private System.Windows.Forms.PictureBox btn_cadastrar;
        private System.Windows.Forms.PictureBox btn_proximoDois;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox txt_valorTotalV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_financas;
        private System.Windows.Forms.PictureBox pic_caldaD;
        private System.Windows.Forms.PictureBox pic_cantod;
        private System.Windows.Forms.PictureBox pic_caldaE;
        private System.Windows.Forms.PictureBox pic_cantoe;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel_produto;
        private System.Windows.Forms.Button lbl_pedido;
        private System.Windows.Forms.Button btn_addProd;
        private System.Windows.Forms.Button btn_limpar;
        private System.Windows.Forms.PictureBox pic_passoUm;
        private System.Windows.Forms.PictureBox pic_passoDois;
        private System.Windows.Forms.Label lbl_obs;
        private System.Windows.Forms.TextBox txt_obs;
        private System.Windows.Forms.Label lbl_qtd;
        private System.Windows.Forms.NumericUpDown txt_quantidade;
        private System.Windows.Forms.ComboBox cb_produtos;
        private System.Windows.Forms.Label lbl_produto;
        private System.Windows.Forms.TextBox txt_valorTotal;
        private System.Windows.Forms.Label lbl_valor;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox;
        private MetroFramework.Controls.MetroGrid db_produtos;
        private System.Windows.Forms.Panel panel_produtos;
        private System.Windows.Forms.Button btn_excluir;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox btn_proximo;
        private System.Windows.Forms.TextBox panel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox pic_passoTres;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
    }
}